﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdventureworksShop.Models;
using PagedList;

namespace AdventureworksShop.Controllers
{
    public class ProductAdminController : Controller
    {
        private AdventureWorks2012_DataEntities db = new AdventureWorks2012_DataEntities();

        //
        // GET: /ProductAdmin/
        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "Name desc" : "";
            ViewBag.PriceSortParm = sortOrder == "Price" ? "Price desc" : "Price";

            // Ensure that the search string is still the same, if not reset the page number
            // and redisplay the new results
            if (Request.HttpMethod == "GET")
                searchString = currentFilter;
            else
                page = 1;

            ViewBag.CurrentFilter = searchString;
            var products = from p in db.Products select p;

            switch (sortOrder)
            {
                case "Name desc":
                    products = products.OrderByDescending(p => p.Name);
                    break;

                case "Price":
                    products = products.OrderBy(p => p.ListPrice);
                    break;

                case "Price desc":
                    products = products.OrderByDescending(p => p.ListPrice);
                    break;

                default:
                    products = products.OrderBy(p => p.Name);
                    break;
            }


            //if (!String.IsNullOrEmpty(searchString))
            //{
                // append to the search string
            //}

            // Convert results into a PageList and hand it over to the view
            return View(products.ToPagedList((page ?? 1), 10));
        }


        
        public ActionResult PhotoTest(int id = 332)
        {
            var prod = db.Products.Find(id);
            //var photo = from p in prod.ProductProductPhotoes select p;
            //var img = photo.First();
            //var imgLarge = img.ProductPhoto.LargePhotoFileName;
            //System.IO.File.WriteAllBytes(@"c:\bob.jpg", img.ProductPhoto.LargePhoto);

            return View(prod);
        }

        public ActionResult ProductViewTest(int id)
        {
            var info2 = from p in db.vProductAndDescriptions select p;
            var prod = info2.FirstOrDefault(p => p.ProductID == id);

            if (prod == null)
                return HttpNotFound();

            return View(prod);
        }


        //
        // GET: /ProductAdmin/Details/5

        public ActionResult Details(int id = 0)
        {
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        //
        // GET: /ProductAdmin/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /ProductAdmin/Create

        [HttpPost]
        public ActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                db.Products.Add(product);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(product);
        }

        //
        // GET: /ProductAdmin/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        //
        // POST: /ProductAdmin/Edit/5

        [HttpPost]
        public ActionResult Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                db.Entry(product).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(product);
        }

        //
        // GET: /ProductAdmin/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        //
        // POST: /ProductAdmin/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Product product = db.Products.Find(id);
            db.Products.Remove(product);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}