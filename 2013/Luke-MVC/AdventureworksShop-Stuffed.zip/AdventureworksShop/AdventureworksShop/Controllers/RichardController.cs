﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdventureworksShop.Models;

namespace AdventureworksShop.Controllers
{

    public partial class RichardTestDb : DbContext
    {
        public RichardTestDb()
            : base("name=AdventureWorks2012_DataEntities")
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            throw new UnintentionalCodeFirstException();
        }
    }

    public class RichardController : Controller
    {
        //private AdventureWorks2012_DataEntities db1 = new AdventureWorks2012_DataEntities();
        private RichardTestDb db1 = new RichardTestDb();

        //
        // GET: /Richard/

        public ActionResult Index()
        {
            var r = new Richard
                {
                    CultureID = "en",
                    Description = "this is a test",
                    ListPrice = 100,
                    Name = "Test",
                    ProductID = 994
                };

            return View(r);
        }



        public ActionResult Edit(int id)
        {
            // http://msdn.microsoft.com/en-us/library/ms179882.aspx
            const string sql = @"SELECT
	            a.ProductID,
	            a.Name,
	            a.ListPrice,
	            c.CultureID,
	            d.[Description],
                d.ProductDescriptionID
            FROM Production.Product a
	            inner join Production.ProductModel b on a.ProductModelID = b.ProductModelID
	            inner join Production.ProductModelProductDescriptionCulture c on b.ProductModelID = c.ProductModelID
	            inner join Production.ProductDescription d on c.ProductDescriptionID = d.ProductDescriptionID
            where c.CultureID = 'en'
	            and a.ProductID = 994";

            //var list = db.Database.SqlQuery<Richard>(sql).ToList();
            var list = db1.Database.SqlQuery<Richard>(sql).ToList();

            //db.Database.SqlQuery(sql);

            return View(list[0]);
        }

        [HttpPost]
        public ActionResult Edit(Richard obj)
        {
            if (ModelState.IsValid)
            {
                // Update the Product information
                const string updateProductCmd = @"UPDATE Production.Product
                SET Name = '{0}',
                ListPrice = {1}
                WHERE ProductID = {2}";
                var cmd = String.Format(updateProductCmd, obj.Name, obj.ListPrice, obj.ProductID);
                db1.Database.ExecuteSqlCommand(cmd);

                // Update the description
                const string updateDescSql = @"UPDATE Production.ProductDescription
                SET [Description] = '{0}'
                WHERE ProductDescriptionID = {1}";
                cmd = String.Format(updateDescSql, obj.Description, obj.ProductDescriptionID);
                db1.Database.ExecuteSqlCommand(cmd);

                return RedirectToAction("Edit", obj.ProductID);
            }

            return View(obj);
        }

    }
}
