﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdventureworksShop.Models
{
    public class Richard
    {
        [Key]
        public int ProductID { get; set; }

        public string Name { get; set; }

        // http://stackoverflow.com/questions/10741190/currency-formatting-mvc
        // http://msdn.microsoft.com/en-us/library/system.web.ui.webcontrols.boundfield.dataformatstring.aspx
        // http://stackoverflow.com/questions/13307188/modelstate-isvalid-contains-errors-when-using-mongodb
        
        //[Range(0.01, 9999.99)]
        //[DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:c}")]

        
        //[Required(ErrorMessage = "Price is required")]
        //[UIHint("Currency")]
        //[DisplayFormat(DataFormatString = "{0:F2}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Currency)]
        public decimal ListPrice { get; set; }
        
        public string CultureID { get; set; }
        
        public string Description { get; set; }

        [HiddenInput(DisplayValue = false)]
        public int ProductDescriptionID { get; set; }
    }

    //public class RichardDBContext : DbContext
    //{
        //public DbSet<Richard> Richards { get; set; }
    //}
}