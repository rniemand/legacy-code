﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdventureworksShop.Models;
using PagedList;

namespace AdventureworksShop.Controllers
{
    public class ProductsController : Controller
    {
        private AdventureWorks2012_DataEntities db = new AdventureWorks2012_DataEntities();
        //public IEnumerable<SelectListItem> Locals { get; set; }

        //
        // GET: /Products/

        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page, string locale)
        {
            // Generate a list of all "CultureID" from the DB
            locale = String.IsNullOrEmpty(locale) ? "en" : locale;
            var localLst = new List<string>();
            var localQry = from lan in db.vProductAndDescriptions
                           orderby lan.CultureID
                           select lan.CultureID;
            localLst.AddRange(localQry.Distinct());
            
            
            

            // Publish ViewBag information
            ViewBag.LocalList = new SelectList(localLst);
            ViewBag.SelectedLocale = locale;
            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "Name desc" : "";
            ViewBag.DateSortParm = sortOrder == "Date" ? "Date desc" : "Date";
            ViewBag.CurrentFilter = searchString;

            if (Request.HttpMethod == "GET")
                searchString = currentFilter;
            else
                page = 1;

            
            // Look up all products matching the locale
            var products = from p in db.vProductAndDescriptions select p;
            products = products.Where(p => p.CultureID == locale);
            products = products.OrderBy(p => p.Name);

            //return View(db.vProductAndDescriptions.ToList());
            //return View(products.ToList());
            return View(products.ToPagedList((page ?? 1), 10));
        }



        //
        // GET: /Products/Details/5

        public ActionResult Details(int id = 0)
        {
            vProductAndDescription vproductanddescription = db.vProductAndDescriptions.Find(id);
            if (vproductanddescription == null)
            {
                return HttpNotFound();
            }
            return View(vproductanddescription);
        }

        //
        // GET: /Products/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Products/Create

        [HttpPost]
        public ActionResult Create(vProductAndDescription vproductanddescription)
        {
            if (ModelState.IsValid)
            {
                db.vProductAndDescriptions.Add(vproductanddescription);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(vproductanddescription);
        }

        //
        // GET: /Products/Edit/5

        public ActionResult Edit(int id = 0)
        {
            vProductAndDescription vproductanddescription = db.vProductAndDescriptions.Find(id);
            if (vproductanddescription == null)
            {
                return HttpNotFound();
            }
            return View(vproductanddescription);
        }

        //
        // POST: /Products/Edit/5

        [HttpPost]
        public ActionResult Edit(vProductAndDescription vproductanddescription)
        {
            if (ModelState.IsValid)
            {
                db.Entry(vproductanddescription).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(vproductanddescription);
        }

        //
        // GET: /Products/Delete/5

        public ActionResult Delete(int id = 0)
        {
            vProductAndDescription vproductanddescription = db.vProductAndDescriptions.Find(id);
            if (vproductanddescription == null)
            {
                return HttpNotFound();
            }
            return View(vproductanddescription);
        }

        //
        // POST: /Products/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            vProductAndDescription vproductanddescription = db.vProductAndDescriptions.Find(id);
            db.vProductAndDescriptions.Remove(vproductanddescription);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}