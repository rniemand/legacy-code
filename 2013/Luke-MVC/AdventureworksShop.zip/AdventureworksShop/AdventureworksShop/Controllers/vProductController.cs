﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdventureworksShop.Models;

namespace AdventureworksShop.Controllers
{
    public class vProductController : Controller
    {
        private AdventureWorks2012_DataEntities db = new AdventureWorks2012_DataEntities();

        //
        // GET: /vProduct/

        public ActionResult Index()
        {
            return View(db.vProductAndDescriptions.ToList());
        }

        //
        // GET: /vProduct/Details/5

        public ActionResult Details(int id = 0)
        {
            vProductAndDescription vproductanddescription = db.vProductAndDescriptions.Find(id);
            if (vproductanddescription == null)
            {
                return HttpNotFound();
            }
            return View(vproductanddescription);
        }

        //
        // GET: /vProduct/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /vProduct/Create

        [HttpPost]
        public ActionResult Create(vProductAndDescription vproductanddescription)
        {
            if (ModelState.IsValid)
            {
                db.vProductAndDescriptions.Add(vproductanddescription);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(vproductanddescription);
        }

        //
        // GET: /vProduct/Edit/5

        public ActionResult Edit(int id = 0)
        {
            var product = (from p in db.vProductAndDescriptions select p).FirstOrDefault(p => p.ProductID == id);

            if (product == null)
                return HttpNotFound();

            return View(product);
        }

        //
        // POST: /vProduct/Edit/5

        [HttpPost]
        public ActionResult Edit(vProductAndDescription vproductanddescription)
        {
            if (ModelState.IsValid)
            {
                db.Entry(vproductanddescription).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(vproductanddescription);
        }

        //
        // GET: /vProduct/Delete/5

        public ActionResult Delete(int id = 0)
        {
            vProductAndDescription vproductanddescription = db.vProductAndDescriptions.Find(id);
            if (vproductanddescription == null)
            {
                return HttpNotFound();
            }
            return View(vproductanddescription);
        }

        //
        // POST: /vProduct/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            vProductAndDescription vproductanddescription = db.vProductAndDescriptions.Find(id);
            db.vProductAndDescriptions.Remove(vproductanddescription);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}