﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdventureworksShop.Models
{
    public class Richard
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public string ProductNumber { get; set; }
        public double ListPrice { get; set; }
        public string Description { get; set; }
    }
}