﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AwMvcStore.AwDatabase
{
    public sealed class AwDbContext
    {
        #region Singleton - Constructor
        private static readonly AwDbContext instance = new AwDbContext();

        private AwDbContext()
        {
            Db = new AdventureWorksDbDataContext();
        }

        public static AwDbContext Instance
        {
            get { return instance; }
        } 
        #endregion

        public AdventureWorksDbDataContext Db { get; private set; }

    }
}