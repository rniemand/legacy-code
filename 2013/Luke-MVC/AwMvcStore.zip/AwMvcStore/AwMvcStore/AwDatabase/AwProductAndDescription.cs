﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AwMvcStore.AwDatabase
{
    public class AwProductAndDescription
    {
        public AwProduct Product { get; set; }
        public AwProductDescription ProductDescription { get; set; }
        public AwProductModel ProductModel { get; set; }
        public AwProductModelProductDescriptionCulture ProductModelProductDescriptionCulture { get; set; }
    }
}