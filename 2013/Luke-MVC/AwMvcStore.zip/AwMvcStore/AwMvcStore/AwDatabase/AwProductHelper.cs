﻿using System;
using System.Linq;
using AwMvcStore.Utils;

namespace AwMvcStore.AwDatabase
{
    public static class AwProductHelper
    {

        public static IQueryable<AwProductAndDescription> ListProductsLinq(string locale = "en")
        {
            try
            {
                var products =
                    from p in AwDbContext.Instance.Db.AwProducts
                    join pm in AwDbContext.Instance.Db.AwProductModels on p.ProductModelID equals pm.ProductModelID
                    join pmpc in AwDbContext.Instance.Db.AwProductModelProductDescriptionCultures on pm.ProductModelID
                        equals pmpc.ProductModelID
                    join pd in AwDbContext.Instance.Db.AwProductDescriptions on pmpc.ProductDescriptionID equals
                        pd.ProductDescriptionID
                    where pmpc.CultureID.Contains(locale)
                    select new AwProductAndDescription
                        {
                            Product = p,
                            ProductDescription = pd,
                            ProductModel = pm,
                            ProductModelProductDescriptionCulture = pmpc
                        };

                return products;
            }
            catch (Exception ex)
            {
                // todo: log this
                return null;
            }
        }


        public static AwProductAndDescription GetProductAndDescription(int productId, string locale = "en")
        {
            try
            {
                return (
                           from p in AwDbContext.Instance.Db.AwProducts
                           join pm in AwDbContext.Instance.Db.AwProductModels on p.ProductModelID equals
                               pm.ProductModelID
                           join pmpc in AwDbContext.Instance.Db.AwProductModelProductDescriptionCultures on
                               pm.ProductModelID
                               equals pmpc.ProductModelID
                           join pd in AwDbContext.Instance.Db.AwProductDescriptions on pmpc.ProductDescriptionID equals
                               pd.ProductDescriptionID
                           where pmpc.CultureID.Contains(locale) && p.ProductID.Equals(productId)
                           select new AwProductAndDescription
                               {
                                   Product = p,
                                   ProductDescription = pd,
                                   ProductModel = pm,
                                   ProductModelProductDescriptionCulture = pmpc
                               })
                    .FirstOrDefault();
            }
            catch (Exception ex)
            {
                // todo: log this
                return null;
            }
        }



        public static AwProduct GetProduct(int productId)
        {
            try
            {
                return AwDbContext.Instance.Db.AwProducts.Single(p => p.ProductID == productId);
            }
            catch (Exception ex)
            {
                // todo: log
                return null;
            }
        }

        public static AwProduct GetProductByName(string productName)
        {
            try
            {
                return AwDbContext.Instance.Db.AwProducts.Single(p => p.Name == productName);
            }
            catch (Exception ex)
            {
                // todo: log
                return null;
            }
        }

        public static AwProduct GetProduct(AwProductAndDescription o)
        {
            if (o.Product == null)
                throw new NullReferenceException("The value for Product is NULL");

            try
            {
                return GetProduct(o.Product.ProductID);
            }
            catch (Exception ex)
            {
                // todo: log
                return null;
            }
        }

        public static bool UpdateProduct(AwProductAndDescription o, bool commit = true)
        {
            // todo: check incomming

            try
            {
                var p = GetProduct(o);
                p.Name = o.Product.Name;
                p.ListPrice = o.Product.ListPrice;
                p.ModifiedDate = DateTime.Now;
                if (commit) AwDbContext.Instance.Db.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                // todo: check
            }

            return false;
        }

        public static bool IsValidProductName(int sourceProductId, string targetProductName)
        {
            try
            {
                var isValidName = true;

                // Name is only valid if:
                //      1) There is no name in the DB like "targetProductName"
                //      2) The sourceProductId == productCheck.ProductID
                var productCheck = GetProductByName(targetProductName);
                if (productCheck != null)
                    if (sourceProductId != productCheck.ProductID)
                        isValidName = false;

                return isValidName;
            }
            catch (Exception ex)
            {
                // todo: log
                return false;
            }
        }

        public static bool IsValidProductName(string sourceProductId, string targetProductName)
        {
            // overload helper...

            try
            {
                return IsValidProductName(sourceProductId.ToInt(), targetProductName);
            }
            catch (Exception ex)
            {
                // todo: log
                return false;
            }
        }



        public static AwProductDescription GetProductDescription(int descId)
        {
            try
            {
                return AwDbContext.Instance.Db.AwProductDescriptions.Single(d => d.ProductDescriptionID == descId);
            }
            catch (Exception ex)
            {
                // todo: log
                return null;
            }
        }

        public static AwProductDescription GetProductDescription(AwProductAndDescription o)
        {
            if(o.ProductDescription == null)
                throw new NullReferenceException("The value for ProductDescription is NULL");

            try
            {
                return GetProductDescription(o.ProductDescription.ProductDescriptionID);
            }
            catch (Exception ex)
            {
                // todo: log
                return null;
            }
        }

        public static bool UpdateProductDescription(AwProductAndDescription o, bool commit = true)
        {
            // todo: check incomming

            try
            {
                var desc = GetProductDescription(o);
                desc.Description = o.ProductDescription.Description;
                desc.ModifiedDate = DateTime.Now;
                if (commit) AwDbContext.Instance.Db.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                // todo: log
            }

            return false;
        }



        public static bool UpdateProductAndDescription(AwProductAndDescription o)
        {
            // todo: check incomming

            try
            {
                if (UpdateProduct(o, false) && UpdateProductDescription(o, false))
                {
                    AwDbContext.Instance.Db.SubmitChanges();
                    return true;
                }
                
                // todo: error updating somehow...
            }
            catch (Exception ex)
            {
                // todo: log this
            }

            return false;
        }


    }
}