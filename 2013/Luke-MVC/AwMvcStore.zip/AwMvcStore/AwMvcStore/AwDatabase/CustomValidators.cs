﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data.Linq;
using System.Linq;
using System.Web;

namespace AwMvcStore.AwDatabase
{
    public partial class AwProduct
    {
        partial void OnNameChanging(string value)
        {
            // http://msdn.microsoft.com/en-us/library/cc488527(v=vs.100).aspx
            // http://www.asp.net/mvc/tutorials/older-versions/models-(data)/validating-with-the-idataerrorinfo-interface-cs

            if (!AwProductHelper.IsValidProductName(ProductID, value))
            {
                throw new Exception("The product name must be unique!");
            }
        }

        partial void OnValidate(ChangeAction action)
        {
            // http://msdn.microsoft.com/en-us/library/cc488527(v=vs.100).aspx

            if (action == ChangeAction.Update)
            {
                //throw new ValidationException("hello");
            }

        }

    }
}