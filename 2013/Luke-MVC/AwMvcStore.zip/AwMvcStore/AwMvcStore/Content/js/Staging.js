﻿/* *****************************************************************************
* This is a test JS file for new ideas (saves me adding a new view each time)
***************************************************************************** */

$(document).ready(function() {

    $('input#fireOffTest').click(function () {
        var url = RnCore.fn.GenerateUrl('Ajax/TestEcho');

        var data = {
            hello: 'world',
            i: 'am',
            getting: 'annoyed'
        };

        $.post(url, data, function (json) {
            console.log(json);
        }, 'json');

    });

});