﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using AwMvcStore.AwDatabase;
using AwMvcStore.Utils;

namespace AwMvcStore.Controllers
{
    public class AjaxController : Controller
    {
        // GET: /Ajax/ValidateProductName/id/name
        public ActionResult ValidateProductName(int arg1, string arg2)
        {
            var validName = AwProductHelper.IsValidProductName(arg1, arg2);
            var o = new { productId = arg1, targetName = arg2, isValid = validName };

            // Sleep to show validation...
            Thread.Sleep(300);
            
            return Json(o, JsonRequestBehavior.AllowGet);
        }

        // POST: /Ajax/ValidateProductName/
        [HttpPost]
        public ActionResult ValidateProductName(FormCollection data)
        {
            var productId = data.GetKeyValue("productId").ToInt();
            var targetName = data.GetKeyValue("targetName");
            var o = new {productId, targetName, isValid = AwProductHelper.IsValidProductName(productId, targetName)};

            // Sleep to show validation...
            Thread.Sleep(300);

            return Json(o, JsonRequestBehavior.AllowGet);
        }





        // ============================================================================
        // NOTE: This is a staging area for test code - this is a play area :)
        // ============================================================================
        [HttpPost]
        public ActionResult Test(FormCollection b)
        {
            

            var dic = b.ToDictionary();


            return Json(b);
        }

        public ActionResult Test()
        {
            return View();
        }



        [HttpPost]
        public ActionResult TestEcho(FormCollection echo)
        {
            // http://stackoverflow.com/questions/3502747/how-to-fetch-an-unknown-number-of-post-parameters-in-asp-net-mvc

            return Json(echo.ToDictionary());
        }

    }
}
