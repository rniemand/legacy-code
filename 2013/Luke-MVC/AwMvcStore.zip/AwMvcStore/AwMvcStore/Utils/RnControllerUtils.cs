﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AwMvcStore.Utils
{
    public static class RnControllerUtils
    {

        public static string GetKeyValue(this FormCollection col, string keyName, string defaultVal = "")
        {
            try
            {
                // Check to see if we can find the requested key
                for (var i = 0; i < col.Count; i++)
                    if (col.Keys[i] == keyName)
                        return col.GetValue(keyName).AttemptedValue;

                // If the key was not found, return the default
                return defaultVal;
            }
            catch (Exception ex)
            {
                // todo: log
                return defaultVal;
            }
        }

        public static Dictionary<string, string> ToDictionary(this FormCollection col)
        {
            try
            {
                // Was originally this
                /*
                 var dic = new Dictionary<string, string>();
                    foreach (var key in col.AllKeys)
                        dic.Add(key, col.GetValue(key).AttemptedValue);
                 */

                // Much better
                return col.AllKeys.ToDictionary(key => key, key => col.GetValue(key).AttemptedValue);
            }
            catch (Exception ex)
            {
                // todo: log
                return new Dictionary<string, string>();
            }
        }


    }
}