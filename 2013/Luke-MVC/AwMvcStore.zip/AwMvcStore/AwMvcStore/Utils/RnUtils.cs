﻿using System;

namespace AwMvcStore.Utils
{
    public static class RnUtils
    {
        public static int ToInt(this string s, int defaultVal = 0)
        {
            try
            {
                return int.Parse(s);
            }
            catch (Exception ex)
            {
                // todo: log
                return defaultVal;
            }
        }
    }
}