﻿using System;
using System.Linq;
using AwMvcStore.Models;
using AwMvcStore.Utils;

namespace AwMvcStore.AwDatabase
{
    public static class AwProductHelper
    {
        /// <summary>
        /// Returns a full list of all products in the IQueryable format
        /// </summary>
        /// <param name="locale">The language to use when fetching products</param>
        /// <returns>IQueryable collection of products</returns>
        public static IQueryable<AwProductAndDescription> ListProductsLinq(string locale = "en")
        {
            try
            {
                RnLogger.Instance.LogDebug("Getting a full list of all products", 1010);
                var products =
                    from p in AwDbContext.Instance.Db.AwProducts
                    join pm in AwDbContext.Instance.Db.AwProductModels on p.ProductModelID equals pm.ProductModelID
                    join pmpc in AwDbContext.Instance.Db.AwProductModelProductDescriptionCultures on pm.ProductModelID
                        equals pmpc.ProductModelID
                    join pd in AwDbContext.Instance.Db.AwProductDescriptions on pmpc.ProductDescriptionID equals
                        pd.ProductDescriptionID
                    where pmpc.CultureID.Contains(locale)
                    select new AwProductAndDescription
                        {
                            Product = p,
                            ProductDescription = pd,
                            ProductModel = pm,
                            ProductModelProductDescriptionCulture = pmpc
                        };

                return products;
            }
            catch (Exception ex)
            {
                ex.LogException();
                return null;
            }
        }

        /// <summary>
        /// Returns the product information for the given ProductID
        /// </summary>
        /// <param name="productId">The ProductID to load</param>
        /// <param name="locale">The locale to use when fetching the product description</param>
        /// <returns>The found product information</returns>
        public static AwProductAndDescription GetProductAndDescription(int productId, string locale = "en")
        {
            try
            {
                RnLogger.Instance.LogDebug("Looking for Product and Description for (ProductID: {0}) (Locale: {1})",
                                           1011, productId, locale);
                return (
                           from p in AwDbContext.Instance.Db.AwProducts
                           join pm in AwDbContext.Instance.Db.AwProductModels on p.ProductModelID equals
                               pm.ProductModelID
                           join pmpc in AwDbContext.Instance.Db.AwProductModelProductDescriptionCultures on
                               pm.ProductModelID
                               equals pmpc.ProductModelID
                           join pd in AwDbContext.Instance.Db.AwProductDescriptions on pmpc.ProductDescriptionID equals
                               pd.ProductDescriptionID
                           where pmpc.CultureID.Contains(locale) && p.ProductID.Equals(productId)
                           select new AwProductAndDescription
                               {
                                   Product = p,
                                   ProductDescription = pd,
                                   ProductModel = pm,
                                   ProductModelProductDescriptionCulture = pmpc
                               })
                    .FirstOrDefault();
            }
            catch (Exception ex)
            {
                ex.LogException();
                return null;
            }
        }

        /// <summary>
        /// Returns the product information for the given ProductID
        /// </summary>
        /// <param name="productId">The ProductID to load</param>
        /// <returns>The found product information</returns>
        public static AwProduct GetProduct(int productId)
        {
            try
            {
                RnLogger.Instance.LogDebug("Looking up product (ProductID: {0})", 1012, productId);
                return AwDbContext.Instance.Db.AwProducts.FirstOrDefault(p => p.ProductID == productId);
            }
            catch (Exception ex)
            {
                ex.LogException();
                return null;
            }
        }

        /// <summary>
        /// Returns the product information for the given product name
        /// </summary>
        /// <param name="productName">The name of the product to look up</param>
        /// <returns>The found product information</returns>
        public static AwProduct GetProductByName(string productName)
        {
            try
            {
                RnLogger.Instance.LogDebug("Looking up product (Name: {0})", 1013, productName);
                return AwDbContext.Instance.Db.AwProducts.FirstOrDefault(p => p.Name == productName);
            }
            catch (Exception ex)
            {
                ex.LogException();
                return null;
            }
        }

        /// <summary>
        /// Returns the product information for the given AwProductAndDescription object
        /// </summary>
        /// <param name="o">AwProductAndDescription for the product</param>
        /// <returns>The found product information</returns>
        public static AwProduct GetProduct(AwProductAndDescription o)
        {
            if (o.Product == null)
            {
                RnLogger.Instance.LogWarning("Cannot get product as AwProductAndDescription.AwProduct is NULL", 1014);
                return null;
            }

            try
            {
                return GetProduct(o.Product.ProductID);
            }
            catch (Exception ex)
            {
                ex.LogException();
                return null;
            }
        }

        /// <summary>
        /// Updates product information for the given AwProductAndDescription (commits to DB)
        /// </summary>
        /// <param name="o">The AwProductAndDescription object to update</param>
        /// <param name="commit">True: commit now, False: queue changes</param>
        /// <returns>True: success, False: fail</returns>
        public static bool UpdateProduct(AwProductAndDescription o, bool commit = true)
        {
            if (o == null || o.Product == null)
            {
                RnLogger.Instance.LogWarning("AwProductAndDescription object was NULL", 1005);
                return false;
            }

            try
            {
                RnLogger.Instance.LogDebug("Updaint product information for (ProductID: {0})", 1015, o.Product.ProductID);
                var p = GetProduct(o);
                p.Name = o.Product.Name;
                p.ListPrice = o.Product.ListPrice;
                p.ModifiedDate = DateTime.Now;
                if (commit) AwDbContext.Instance.Db.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return false;
        }

        /// <summary>
        /// Validates if the given ProductId / Name is valid
        /// </summary>
        /// <param name="sourceProductId">ProductID for the product we are wantin to rename</param>
        /// <param name="targetProductName">The desired new product name</param>
        /// <returns>True: name is valid, False: name is not valid</returns>
        public static bool IsValidProductName(int sourceProductId, string targetProductName)
        {
            try
            {
                var isValidName = true;

                // ============================================================================
                // Our product name is only valid if...
                // ============================================================================
                //      1) There is no name in the DB like "targetProductName"
                //      2) The sourceProductId == productCheck.ProductID
                // ============================================================================
                RnLogger.Instance.LogDebug("Validating product name (ID: {0}) (New Name: {1})", 1000, sourceProductId,
                                           targetProductName);
                var productCheck = GetProductByName(targetProductName);
                if (productCheck != null)
                    if (sourceProductId != productCheck.ProductID)
                    {
                        RnLogger.Instance.LogWarning("Caught invalid product name '{0}'. (ID: {1})", 1001,
                                                     targetProductName, sourceProductId);
                        isValidName = false;
                    }

                return isValidName;
            }
            catch (Exception ex)
            {
                ex.LogException();
                return false;
            }
        }

        /// <summary>
        /// Validates if the given ProductId / Name is valid
        /// </summary>
        /// <param name="sourceProductId">ProductID for the product we are wantin to rename</param>
        /// <param name="targetProductName">The desired new product name</param>
        /// <returns>True: name is valid, False: name is not valid</returns>
        public static bool IsValidProductName(string sourceProductId, string targetProductName)
        {
            return IsValidProductName(sourceProductId.AsInt(), targetProductName);
        }

        /// <summary>
        /// Fetches the product description for the given ProductDescriptionID
        /// </summary>
        /// <param name="descId">The ProductDescriptionID to look up</param>
        /// <returns>The found product description</returns>
        public static AwProductDescription GetProductDescription(int descId)
        {
            try
            {
                RnLogger.Instance.LogDebug("Looking up description for (ProductDescriptionID: {0})", 1016, descId);
                return
                    AwDbContext.Instance.Db.AwProductDescriptions.FirstOrDefault(d => d.ProductDescriptionID == descId);
            }
            catch (Exception ex)
            {
                ex.LogException();
                return null;
            }
        }

        /// <summary>
        /// Fetches the product description for the given ProductDescriptionID
        /// </summary>
        /// <param name="o">The AwProductAndDescription to look up</param>
        /// <returns>The found product description</returns>
        public static AwProductDescription GetProductDescription(AwProductAndDescription o)
        {
            if (o.ProductDescription == null)
            {
                RnLogger.Instance.LogWarning(
                    "Cannot get AwProductDescription as AwProductDescription.ProductDescription is NULL", 1017);
                return null;
            }

            try
            {
                return GetProductDescription(o.ProductDescription.ProductDescriptionID);
            }
            catch (Exception ex)
            {
                ex.LogException();
                return null;
            }
        }

        /// <summary>
        /// Commits/Updates the current product description to the DB
        /// </summary>
        /// <param name="o">The AwProductAndDescription object to commit</param>
        /// <param name="commit">True: save now, False: queue</param>
        /// <returns>True on success</returns>
        public static bool UpdateProductDescription(AwProductAndDescription o, bool commit = true)
        {
            if (o == null || o.Product == null)
            {
                RnLogger.Instance.LogWarning("AwProductAndDescription object was NULL", 1005);
                return false;
            }

            try
            {
                RnLogger.Instance.LogDebug("Updating product description (ProductDescriptionID: {0})", 1018,
                                           o.ProductDescription.ProductDescriptionID);
                var desc = GetProductDescription(o);
                desc.Description = o.ProductDescription.Description;
                desc.ModifiedDate = DateTime.Now;
                if (commit) AwDbContext.Instance.Db.SubmitChanges();
                return true;
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return false;
        }

        /// <summary>
        /// Commits/Updates the current product description to the DB
        /// </summary>
        /// <param name="o">The AwProductAndDescription object to commit</param>
        /// <returns>True on success</returns>
        public static bool UpdateProductAndDescription(AwProductAndDescription o)
        {
            if (o == null || o.Product == null)
            {
                RnLogger.Instance.LogWarning("AwProductAndDescription object was NULL", 1005);
                return false;
            }

            try
            {
                if (UpdateProduct(o, false) && UpdateProductDescription(o, false))
                {
                    AwDbContext.Instance.Db.SubmitChanges();
                    return true;
                }

                RnLogger.Instance.LogWarning("There was an issue updating the product information", 1006);
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return false;
        }


    }
}