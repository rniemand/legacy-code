﻿using System;

namespace AwMvcStore.AwDatabase
{
    public partial class AwProduct
    {
        // This hook allows me to catch the “OnNameChanging” event and allow me to apply business logic to the product name
        // (namely uniqueness and null values) and if needs be invalidate the object if it fails the checks
        void OnNameChanging(string value)
        {
            // http://msdn.microsoft.com/en-us/library/cc488527(v=vs.100).aspx
            // http://www.asp.net/mvc/tutorials/older-versions/models-(data)/validating-with-the-idataerrorinfo-interface-cs

            // Make sure that the name conforms with our restrictions
            if (!AwProductHelper.IsValidProductName(ProductID, value))
            {
                throw new Exception("The product name must be unique!");
            }
        }

        /*
        // I was going to initially use this, but changed my mind as it did not offer what I wanted
        partial void OnValidate(ChangeAction action)
        {
            // http://msdn.microsoft.com/en-us/library/cc488527(v=vs.100).aspx

            if (action == ChangeAction.Update)
            {
                //throw new ValidationException("hello");
            }

        }
        */
    }

    /* *************************************************************************************
     * This was my initial attempt at setting the display type for the products price. I 
     * decided to modify the generated LINQ 2 SQL code so that the ListPrice value would 
     * be generated as virtual and I would override it here and set values. This did not 
     * have the desired effect though so I just created a helper class to do all this as 
     * I needed to add in additional functionality anyways. That class name was called 
     * AwProductAndDescription
     ************************************************************************************* */

    /*
    public class AwProductOr : AwProduct
    {
        private decimal _listPrice;

        [DataType(DataType.Currency)]
        public override decimal ListPrice { get { return 99; } set { _listPrice = value; } }
    }
    */

}