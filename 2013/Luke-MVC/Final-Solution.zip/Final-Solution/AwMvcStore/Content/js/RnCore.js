﻿/* *****************************************************************************
* RnCore.js
*   Helper JS library for all site stuff
***************************************************************************** */

/*
    Yup - I do know what an anonymous JS function is, I just didn’t know it was called 
    that at the time of the interview and have been kicking myself ever since finding 
    out that I have been using them since I started playing with jQuery last year
        #Rant Over :(
*/
(function (window) {
    var rnCore = {
        Version: { Major: 1, Minor: 0, Build: 0 },
        URL: { base: null },
        fn: []
    };

    // Setup basics
    rnCore.Version.ToString = function () { return this.Major + '.' + this.Minor + '.' + this.Build; };
    rnCore.URL.base = window.location.protocol + '//' + window.location.host + '/';
    rnCore.fn.GenerateUrl = function(append) {
        return typeof append === "undefined" ? rnCore.URL.base : rnCore.URL.base + append;
    };

    // Attatch rnCore to "window.RnCore"
    window.RnCore = rnCore;
})(window);
