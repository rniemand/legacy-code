﻿$(document).ready(function () {
    $('div#filterResults').StoreSearch({
        searchUrl: RnCore.fn.GenerateUrl('Ajax/StoreSearch')
    });
});