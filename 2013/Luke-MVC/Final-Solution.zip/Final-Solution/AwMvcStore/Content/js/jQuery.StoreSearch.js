﻿(function($){
    var defaultOptions = {
        fSearchName: 'advancedSearch',
        fSearchId: 'advancedSearch',
        fSearchClass: '',
        filterDivClass: 'searchFilter',
        resultsDivClass: 'searchResults',
        rangeFieldName: 'limit',
        rangeFieldId: 'limit',
        rangeFieldClass: '',
        rangeMaxResults: 100,
        rangeStartPos: 10,
        rangeIncrementsIn: 5,
        orderByName: 'orderBy',
        orderById: 'orderBy',
        orderByClass: '',
        bSearchName: 'doSearch',
        bSearchId: 'doSearch',
        bSearchClass: '',
        bSearchText: 'Search',
        searchUrl: null,
        minSearchLength: 3,
        useCookies: true,
        cookieId: 'rnSearch'
    };
    
    $.fn.StoreSearch = function (opt) {
        return this.each(function() {
            if (!this.StoreSearch) {
                opt = opt || {};
                var o = $.extend(true, {}, defaultOptions, opt);
                this.StoreSearch = new storeSearch($(this), o);
            } else {
                if (this.StoreSearch[opt]) {
                    this.StoreSearch[opt].apply(this.rnDD);
                } else {
                    // Attempted to invoke an unknown method on this plugin...
                    //console.log('unknown method...');
                }
            }
        });
    };

    function storeSearch(targetElement, options) {
        // Set this to $this
        var $this = this;

        $this.selectors = {
            $targetEl: targetElement,
            $filterDiv: null,
            $resultsDiv: null,
            $iSearch: null,
            $sRange: null,
            $sOrder: null,
            $bSearch: null,
            $lClearCookies: null
        };

        // Methods
        $this.fn = {
            init: function () {
                $this.fn.initCreateInputs();
                $this.fn.loadFromCookie();
            },
            
            loadFromCookie: function() {
                if (!options.useCookies)
                    return;

                var _cookieData = $.cookie(options.cookieId);
                if (_cookieData === null) return;
                var cookieData = JSON.parse(_cookieData);

                if (typeof cookieData.searchTerm !== 'undefined')
                    $this.selectors.$iSearch.val(cookieData.searchTerm);
                
                if (typeof cookieData.limit !== 'undefined')
                    $this.selectors.$sRange.val(cookieData.limit);
                
                if (typeof cookieData.sortBy !== 'undefined')
                    $this.selectors.$sOrder.val(cookieData.sortBy);

                if ($this.selectors.$iSearch.val().length >= options.minSearchLength)
                    $this.fn.RunSearch();
            },
            
            initCreateInputs: function () {
                // DIVs used for results / data
                $this.selectors.$filterDiv = $('<div />').addClass(options.filterDivClass);
                $this.selectors.$resultsDiv = $('<div />').addClass(options.resultsDivClass);

                // Forget cookies
                if (options.useCookies) {
                    $this.selectors.$lClearCookies = $('<a />')
                        .html($('<img />')
                            .attr({
                                alt: 'Clear Results',
                                title: 'Clear Results',
                                src: '/Images/16x16/erasor.png'
                            })
                        )
                        .attr('href', '#')
                        .addClass('imgLink')
                        .click(function () {
                            $.removeCookie(options.cookieId);
                            $this.selectors.$resultsDiv.empty();
                            $this.selectors.$iSearch.val('');
                            $this.selectors.$sRange.val(options.rangeStartPos);
                            $this.selectors.$sOrder.val('name');
                        });

                    $this.selectors.$filterDiv.append($this.selectors.$lClearCookies);
                }

                // Search Field
                $this.selectors.$iSearch = $('<input type="text" />').attr({
                    id: options.fSearchId,
                    name: options.fSearchName,
                    'class': options.fSearchClass
                }).keydown(function(e) {
                     if (e.which == 13) { $this.fn.RunSearch(); };
                });
                $this.selectors.$filterDiv.append($this.selectors.$iSearch);

                // Results LIMIT
                $this.selectors.$sRange = $('<select />').attr({
                    id: options.rangeFieldId,
                    name: options.rangeFieldName,
                    'class': options.rangeFieldName
                });
                for (var i = options.rangeStartPos; i <= options.rangeMaxResults; i += options.rangeIncrementsIn) {
                    $this.selectors.$sRange.append($('<option />').val(i).html('Show ' + i + ' Result(s)'));
                }
                $this.selectors.$sRange.val(options.rangeStartPos); // default select
                $this.selectors.$filterDiv.append($this.selectors.$sRange);

                // Order clause
                $this.selectors.$sOrder = $('<select />').attr({
                    id: options.orderById,
                    name: options.orderByName,
                    'class': options.orderByClass
                });
                // would make this configurable
                $this.selectors.$sOrder.append($('<option />').val('name').html('Name'));
                $this.selectors.$sOrder.append($('<option />').val('name desc').html('Name Desc.'));
                $this.selectors.$sOrder.append($('<option />').val('price').html('Price'));
                $this.selectors.$sOrder.append($('<option />').val('price desc').html('Price Desc.'));
                $this.selectors.$sOrder.append($('<option />').val('model').html('Model'));
                $this.selectors.$sOrder.append($('<option />').val('model desc').html('Model Desc.'));
                $this.selectors.$sOrder.append($('<option />').val('desc').html('Description'));
                $this.selectors.$sOrder.append($('<option />').val('desc desc').html('Description Desc.'));
                $this.selectors.$filterDiv.append($this.selectors.$sOrder);

                // Search button
                $this.selectors.$bSearch = $('<input type="button" />').attr({
                    id: options.bSearchId,
                    name: options.bSearchName,
                    'class': options.bSearchClass,
                    value: options.bSearchText
                }).click(function() {
                     $this.fn.RunSearch();
                });
                $this.selectors.$filterDiv.append($this.selectors.$bSearch);

                $this.selectors.$targetEl.empty().append($this.selectors.$filterDiv).append($this.selectors.$resultsDiv);
            },
            
            GeneratePostData: function () {
                var postData = {
                    searchTerm: $this.selectors.$iSearch.val(),
                    sortBy: $this.selectors.$sOrder.val(),
                    limit: $this.selectors.$sRange.val()
                };
                
                if (options.useCookies) {
                    $.cookie(options.cookieId, JSON.stringify(postData));
                }

                return postData;
            },

            RunSearch: function () {
                // Ensure that there is some user input
                if ($this.selectors.$iSearch.val().length === 0) {
                    alert('You need to enter in a search string!');
                    $this.selectors.$iSearch.focus();
                    return;
                }
                
                // Ensure that the minSearchLength is met
                if ($this.selectors.$iSearch.val().length < options.minSearchLength) {
                    alert('You need to enter in a search term longer than ' + options.minSearchLength + ' letters');
                    $this.selectors.$iSearch.focus();
                    return;
                }

                // Indicate that we are running the search
                $this.selectors.$resultsDiv.html('Running search...');
                $.post(options.searchUrl, $this.fn.GeneratePostData(), function (json) {
                    if (json.length > 0) {
                        $this.fn.GenerateSearchResults(json);
                    } else {
                        $this.fn.DisplayNoResults();
                    }
                }, 'json').fail(function (jqXHR, textStatus) {
                    alert('Error getting results: ' + textStatus);
                });
            },
            
            GenerateSearchResults: function (json) {
                $this.selectors.$resultsDiv.empty();
                $this.fn.GenerateSearchHead(json);
                
                // Create our results table
                var $table = $('<table />')
                    .addClass('productList')
                    .append(
                        $('<tr />')
                        .append($('<th >').html('Name'))
                        .append($('<th >').html('Model'))
                        .append($('<th >').html('Price'))
                        .append($('<th >').html('Description'))
                        .append($('<th >').html(''))
                    );

                $.each(json, function (ix, data) {
                    var $link = $('<a />').html(
                        $('<img />').attr({
                            src: RnCore.fn.GenerateUrl('Images/16x16/details.png'),
                            alt: 'View product details',
                            title: 'View product details'
                        }))
                        .attr({ href: RnCore.fn.GenerateUrl('Store/Details/' + data.ProductId) })
                        .addClass('imgLink');

                    $table.append(
                        $('<tr />')
                            .append($('<td />').html(data.ProductName))
                            .append($('<td />').html(data.ProductModel))
                            .append($('<td />').html(data.ProductPrice))
                            .append($('<td />').html(data.ProductDescriptionShort))
                            .append($('<td />').html($link).addClass('shopActions'))
                    );
                });

                $this.selectors.$resultsDiv.append($table);
            },
            
            GenerateSearchHead: function (json) {
                var $infoDiv = $('<div />').append($('<p />')
                    .append('Your search for "<strong>' + $this.selectors.$iSearch.val() + '</strong>" ')
                    .append('returned <strong>' + json.length + '</strong> results.')
                );
                
                if (json.length > 30) {
                    $infoDiv.append($('<p />')
                        .append('Try refining your search to get less results')
                        .addClass('note')
                    );
                }
                
                $this.selectors.$resultsDiv.append($infoDiv);
            },
            
            DisplayNoResults: function () {
                $this.selectors.$resultsDiv.html($('<p />')
                    .append('There were no results matching your search, please try again.')
                    .addClass('note')
                );
            }
        };

        $this.fn.init();
        return $this;
    }
})(jQuery);