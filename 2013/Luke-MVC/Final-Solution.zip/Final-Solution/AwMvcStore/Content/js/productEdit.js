﻿/* ********************************************************************************************************
* EDIT FORM VALIDATION
* ********************************************************************************************************
*   Please note below the use of the following.
*
*       1 The use of both a POST and a GET method to do the name validation.
*       2 The code behind the GET and POST methods.
*       3 The failsafe server side validation should JS be disabled.
*       4 The use of a global helper object "RnCore".
*       5 The use of a simple configuration object to pass between helps.
*       6 How the validation is called, onLoad, onBlur and onKeydown with event cancellation.
*       7 The helper class I created in C# for getting POST values.
*
******************************************************************************************************** */

$(document).ready(function () {
    // Not needed, but was from initial testing
    ValidateName(false, false);

    // Validate when focus is lost
    $('input#Name').blur(function () {
         ValidateName(true, false);
    });

    // Validate if user trys to submit the form (ENTER)
    $('input#Name').keydown(function (event) {
        if (event.which == 13) {
            event.stopPropagation();
            event.preventDefault();
            ValidateName(true, true);
            return false;
        }
    });
});


function ValidateName(usePost, submitForm) {
    // Set up the general configuration object
    var opt = {
        cssDisabled: 'disabled',
        cssValErrInput: 'input-validation-error',
        cssValErrField: 'field-validation-error',
        $submit: $('input#submitForm'),
        $inputName: $('input#Name'),
        $valIndicator: $('span#validationIndicator'),
        $checkingGif: $('<img />').attr('src', RnCore.fn.GenerateUrl('/Images/16x16/spinner.gif')),
        $productId: $('input#Product_ProductID').val(),
        currentVal: null,
        baseUrl: null,
        submitForm: false
    };
    
    // Set the current value, BaseURL and if we need to submit the form
    opt.currentVal = opt.$inputName.val();
    opt.baseUrl = RnCore.fn.GenerateUrl('/Ajax/ValidateProductName');
    opt.submitForm = submitForm;
    
    // Ensure that we have a value to work with first
    opt.$submit.attr('disabled', true).addClass(opt.cssDisabled);
    opt.$inputName.attr('disabled', true).addClass(opt.cssDisabled);
    if (opt.currentVal.length == 0) {
        opt.$inputName.addClass(opt.cssValErrInput).removeClass(opt.cssDisabled).attr('disabled', false);
        opt.$valIndicator.addClass(opt.cssValErrField).html('Product name cannot be blank!');
        return;
    }

    // Fire off the correct validation method based on "usePost"
    opt.$valIndicator.html(opt.$checkingGif).removeClass(opt.cssValErrField);
    usePost ? ValidateNameViaPOST(opt) : ValidateNameViaGET(opt);
}

function ValidateNameViaGET(opt) {
    // Generate the GET URL that maps to "~Ajax/ValidateProductName/ID/NAME"
    var url = opt.baseUrl + '/' + opt.$productId + '/' + opt.currentVal;
    $.getJSON(url, {}, function(json) {
        opt.$inputName.attr('disabled', false).removeClass(opt.cssDisabled);
        opt.$valIndicator.html('');

        if (json.isValid) {
            // If valid, reset classes / errors and submit the form if needs be
            opt.$inputName.removeClass(opt.cssValErrInput);
            opt.$submit.attr('disabled', false).removeClass(opt.cssDisabled);
            if (opt.submitForm) $('form#mainForm').submit();
            return;
        }

        // The product name is not valid, tell the user, keep stuff disabled
        opt.$inputName.addClass(opt.cssValErrInput);
        opt.$valIndicator.addClass(opt.cssValErrField).html('A product with the name "' + opt.currentVal + '" already exists!');
    }).fail(function (jqXHR, textStatus) {
        // Eish, call to server failed, tell the user (include error)
        opt.$valIndicator.addClass(opt.cssValErrField).html('There was an error contacting the server (' + textStatus + ')...');
        opt.$inputName.attr('disabled', false).removeClass(opt.cssDisabled);
        opt.$submit.attr('disabled', false).removeClass(opt.cssDisabled);
    });
}

function ValidateNameViaPOST(opt) {
    // Generate and fire our POST request
    var postData = { productId: opt.$productId, targetName: opt.currentVal };

    $.post(opt.baseUrl, postData, function(json) {
        opt.$inputName.attr('disabled', false).removeClass(opt.cssDisabled);
        opt.$valIndicator.html('');

        if (json.isValid) {
            // If valid, reset classes / errors and submit the form if needs be
            opt.$inputName.removeClass(opt.cssValErrInput);
            opt.$submit.attr('disabled', false).removeClass(opt.cssDisabled);
            if (opt.submitForm) $('form#mainForm').submit();
            return;
        }

        // The product name is not valid, tell the user, keep stuff disabled
        opt.$inputName.addClass(opt.cssValErrInput);
        opt.$valIndicator.addClass(opt.cssValErrField).html('A product with the name "' + opt.currentVal + '" already exists!');
    }, 'json').fail(function (jqXHR, textStatus) {
        // Eish, call to server failed, tell the user (include error)
        opt.$valIndicator.addClass(opt.cssValErrField).html('There was an error contacting the server (' + textStatus + ')...');
        opt.$inputName.attr('disabled', false).removeClass(opt.cssDisabled);
        opt.$submit.attr('disabled', false).removeClass(opt.cssDisabled);
    });
}

