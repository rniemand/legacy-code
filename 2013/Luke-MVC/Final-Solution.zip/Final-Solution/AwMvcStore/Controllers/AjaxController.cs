﻿using System.Linq;
using System.Threading;
using System.Web.Mvc;
using AwMvcStore.AwDatabase;
using AwMvcStore.Filters;
using AwMvcStore.Utils;

namespace AwMvcStore.Controllers
{
    [RnActionFilters]
    public class AjaxController : Controller
    {
        // GET: /Ajax/ValidateProductName/id/name
        public ActionResult ValidateProductName(int arg1, string arg2)
        {
            var validName = AwProductHelper.IsValidProductName(arg1, arg2);
            var o = new {productId = arg1, targetName = arg2, isValid = validName};

            // Sleep to show validation...
            Thread.Sleep(300);

            return Json(o, JsonRequestBehavior.AllowGet);
        }

        // POST: /Ajax/ValidateProductName/
        [HttpPost]
        public ActionResult ValidateProductName(FormCollection data)
        {
            var productId = data.GetKeyValue("productId").AsInt();
            var targetName = data.GetKeyValue("targetName");
            var o = new {productId, targetName, isValid = AwProductHelper.IsValidProductName(productId, targetName)};

            // Sleep to show validation...
            Thread.Sleep(300);

            return Json(o, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult StoreSearch(FormCollection data)
        {
            // Original query logic
            /*
             * //var products = AwProductHelper.ListProductsLinq();
            var products =
                from p in AwDbContext.Instance.Db.AwProducts
                join pm in AwDbContext.Instance.Db.AwProductModels on p.ProductModelID equals pm.ProductModelID
                join pmpc in AwDbContext.Instance.Db.AwProductModelProductDescriptionCultures on pm.ProductModelID
                    equals pmpc.ProductModelID
                join pd in AwDbContext.Instance.Db.AwProductDescriptions on pmpc.ProductDescriptionID equals
                    pd.ProductDescriptionID
                where pmpc.CultureID.Contains("en")
                select new
                    {
                        ProductName = p.Name,
                        ProductId = p.ProductID,
                        ProductDescription = pd.Description,
                        ProductDescriptionLocale = pmpc.CultureID,
                        ProductPrice = p.ListPrice,
                        ProductModel = pm.Name,
                        ProductDescriptionShort = pd.Description.GetXWords(20, "...")
                    };
             * 
             * // Filter on the search term
            var term = data.GetKeyValue("searchTerm");
            if (!String.IsNullOrEmpty(term))
            {
                products = products.Where(
                    p =>
                    p.ProductName.Contains(term) ||
                    p.ProductDescription.Contains(term) ||
                    p.ProductModel.Contains(term)
                    );
            }
             * 
             * // Sort the products
            var sortBy = data.GetKeyValue("sortBy", "ProductName");
            switch (sortBy.ToLower().Trim())
            {
                case "price":
                    products = products.OrderBy(p => p.ProductPrice);
                    break;
                case "price desc":
                    products = products.OrderByDescending(p => p.ProductPrice);
                    break;
                case "model":
                    products = products.OrderBy(p => p.ProductModel);
                    break;
                case "model desc":
                    products = products.OrderByDescending(p => p.ProductModel);
                    break;
                case "desc":
                    products = products.OrderBy(p => p.ProductDescription);
                    break;
                case "desc desc":
                    products = products.OrderByDescending(p => p.ProductDescription);
                    break;
                case "name desc":
                    products = products.OrderByDescending(p => p.ProductName);
                    break;
                default:
                    products = products.OrderBy(p => p.ProductName);
                    break;
            }
             * 
             * // Limit the # of results
            var limit = data.GetKeyValue("limit").AsInt();
            if (limit > 0) products = products.Take(limit);
            */

            // I think this looks a lot better
            var products = StoreSearchHelper.GenerateBaseQuery()
                                            .ApplySearchTerm(data.GetKeyValue("searchTerm"))
                                            .ApplyOrdering(data.GetKeyValue("sortBy", "ProductName"))
                                            .ApplyLimit(data.GetKeyValue("limit"));
            var lProducts = products.ToList();
            RnLogger.Instance.LogDebug("Found a total of '{0}' results", 1023, lProducts.Count);

            // To emulate a server request...
            Thread.Sleep(350);
            return Json(lProducts);
        }



        // ============================================================================
        // NOTE: This is a staging area for test code - this is a play area :)
        // ============================================================================
        [HttpPost]
        public ActionResult Test(FormCollection b)
        {
            var dic = b.ToDictionary();
            return Json(b);
        }

        public ActionResult Test()
        {
            return View();
        }

        [HttpPost]
        public ActionResult TestEcho(FormCollection echo)
        {
            // http://stackoverflow.com/questions/3502747/how-to-fetch-an-unknown-number-of-post-parameters-in-asp-net-mvc

            return Json(echo.ToDictionary());
        }
    }

}
