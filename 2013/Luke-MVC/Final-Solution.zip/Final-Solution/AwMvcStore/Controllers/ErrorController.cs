﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AwMvcStore.Filters;
using AwMvcStore.Utils;

namespace AwMvcStore.Controllers
{
    [RnActionFilters]
    public class ErrorController : Controller
    {
        //
        // GET: /Error/

        public ActionResult E404()
        {
            if (Request.Url != null)
                RnLogger.Instance.LogError("Page not found", Request, 1002);

            return View();
        }

    }
}
