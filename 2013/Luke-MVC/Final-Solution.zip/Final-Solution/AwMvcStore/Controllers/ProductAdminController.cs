﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using AwMvcStore.AwDatabase;
using AwMvcStore.Filters;
using AwMvcStore.Models;
using AwMvcStore.Utils;
using PagedList;

namespace AwMvcStore.Controllers
{
    [RnActionFilters]
    public class ProductAdminController : Controller
    {
        // =======================================
        // GET: /ProductAdmin/
        // =======================================
        public ActionResult Index(string sort, string filter, int? page)
        {
            // Set up the sorting shortcuts
            ViewBag.CurrentSort = sort;
            ViewBag.sortOnName = String.IsNullOrEmpty(sort) ? "nDesc" : "";
            ViewBag.sortOnPrice = sort == "pr" ? "prDesc" : "pr";
            ViewBag.sortOnDesc = sort == "d" ? "dDesc" : "d";
            ViewBag.sortOnModel = sort == "m" ? "mDesc" : "m";
            var searchString = "";

            // Check to see if the user is filtering (GET = continue, POST = new)
            if (Request.HttpMethod == "GET")
                searchString = filter;
            else
                page = 1;

            ViewBag.CurrentFilter = searchString;

            // Generate our initial select statement
            var products = AwProductHelper.ListProductsLinq();

            if (!String.IsNullOrEmpty(searchString))
            {
                // Search on all fields listed
                products = products.Where(
                    p =>
                    p.Product.Name.Contains(searchString) ||
                    p.ProductModel.Name.Contains(searchString) ||
                    p.ProductDescription.Description.Contains(searchString)
                    );
            }

            // Apply sorting to our select statement
            switch (sort)
            {
                case "m":
                    products = products.OrderBy(p => p.ProductModel.Name);
                    break;
                case "mDesc":
                    products = products.OrderByDescending(p => p.ProductModel.Name);
                    break;
                case "d":
                    products = products.OrderBy(p => p.ProductDescription.Description);
                    break;
                case "dDesc":
                    products = products.OrderByDescending(p => p.ProductDescription.Description);
                    break;
                case "pr":
                    products = products.OrderBy(p => p.Product.ListPrice);
                    break;
                case "prDesc":
                    products = products.OrderByDescending(p => p.Product.ListPrice);
                    break;
                case "nDesc":
                    products = products.OrderByDescending(p => p.Product.Name);
                    break;
                default:
                    products = products.OrderBy(p => p.Product.Name);
                    break;
            }

            // Log each time this page is called (used to test filtering on logging severity [Web.config -> Rn.Logging.LoggingLevel])
            RnLogger.Instance.LogInfo("Rendering Product Admin Page", 200);
            return View(products.ToPagedList((page ?? 1), 10));
        }


        // =======================================
        // GET: /ProductAdmin/Edit/5
        // =======================================
        public ActionResult Edit(int id)
        {
            var product = AwProductHelper.GetProductAndDescription(id);

            if (product == null)
                return HttpNotFound();

            return View(product);
        }

        [HttpPost]
        public ActionResult Edit(AwProductAndDescription o)
        {
            if (ModelState.IsValid)
            {
                AwProductHelper.UpdateProductAndDescription(o);
                return RedirectToAction("Index");
            }

            return View(o);
        }


        // =======================================
        // GET: /ProductAdmin/Details/5
        // =======================================
        public ActionResult Details(int id)
        {
            var product = AwProductHelper.GetProductAndDescription(id);

            if (product == null)
                return HttpNotFound();

            return View(product);
        }


        // =======================================
        // GET: /ProductAdmin/ViewLog/5
        // =======================================
        public ActionResult ViewLog(int? limit, string severity = "all")
        {
            // tired, hack for now...
            if (limit == null) limit = 25;
            var logLInes = limit.ToString().AsInt();
            var lines = RnLogFileData.GetLogLines(logLInes, severity);
            
            ViewBag.Limit = logLInes;
            ViewBag.Severity = severity;

            return View(lines);
        }

    }
    
}
