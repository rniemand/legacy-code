﻿using System;
using System.Linq;
using System.Web.Mvc;
using AwMvcStore.AwDatabase;
using AwMvcStore.Filters;
using AwMvcStore.Utils;
using PagedList;

namespace AwMvcStore.Controllers
{
    public class StoreController : Controller
    {
        [RnActionFilters]
        public ActionResult Index(string sort, string filter, int? page)
        {
            // Set up the sorting shortcuts
            ViewBag.CurrentSort = sort;
            ViewBag.sortOnName = String.IsNullOrEmpty(sort) ? "nDesc" : "";
            ViewBag.sortOnPrice = sort == "pr" ? "prDesc" : "pr";
            ViewBag.sortOnDesc = sort == "d" ? "dDesc" : "d";
            ViewBag.sortOnModel = sort == "m" ? "mDesc" : "m";
            var searchString = "";

            // Check to see if the user is filtering (GET = continue, POST = new)
            if (Request.HttpMethod == "GET")
                searchString = filter;
            else
                page = 1;

            ViewBag.CurrentFilter = searchString;

            // Generate our initial select statement
            var products = AwProductHelper.ListProductsLinq();

            if (!String.IsNullOrEmpty(searchString))
            {
                // Search on all fields listed
                products = products.Where(
                    p =>
                    p.Product.Name.Contains(searchString) ||
                    p.ProductModel.Name.Contains(searchString) ||
                    p.ProductDescription.Description.Contains(searchString)
                    );
            }

            // Apply sorting to our select statement
            switch (sort)
            {
                case "m":
                    products = products.OrderBy(p => p.ProductModel.Name);
                    break;
                case "mDesc":
                    products = products.OrderByDescending(p => p.ProductModel.Name);
                    break;
                case "d":
                    products = products.OrderBy(p => p.ProductDescription.Description);
                    break;
                case "dDesc":
                    products = products.OrderByDescending(p => p.ProductDescription.Description);
                    break;
                case "pr":
                    products = products.OrderBy(p => p.Product.ListPrice);
                    break;
                case "prDesc":
                    products = products.OrderByDescending(p => p.Product.ListPrice);
                    break;
                case "nDesc":
                    products = products.OrderByDescending(p => p.Product.Name);
                    break;
                default:
                    products = products.OrderBy(p => p.Product.Name);
                    break;
            }

            // Log each time this page is called (used to test filtering on logging severity [Web.config -> Rn.Logging.LoggingLevel])
            RnLogger.Instance.LogInfo("User requesting store page", 200);
            return View(products.ToPagedList((page ?? 1), 10));
        }

        public ActionResult Details(int id)
        {
            var product = AwProductHelper.GetProductAndDescription(id);

            if (product == null)
                return HttpNotFound();

            return View(product);
        }

        public ActionResult Search()
        {
            return View();
        }

    }
}
