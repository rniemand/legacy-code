﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AwMvcStore.Utils;

namespace AwMvcStore.Filters
{
    public class RnActionFilters : ActionFilterAttribute
    {
        // http://richarddingwall.name/2008/08/17/strategies-for-resource-based-404-errors-in-aspnet-mvc/

        /// <summary>
        /// Called by the ASP.NET MVC framework before the action method executes.
        /// </summary>
        /// <param name="filterContext">The filter context.</param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            try
            {
                // Log the page request...
                const string msg = @"({0}) ""{1}\{2}"" (IP: {3}) (Server Time: {4})";
                RnLogger.Instance.LogActionCall(
                    msg, filterContext.HttpContext.Request, 101,
                    filterContext.RequestContext.HttpContext.Request.RequestType,
                    filterContext.ActionDescriptor.ControllerDescriptor.ControllerName,
                    filterContext.ActionDescriptor.ActionName,
                    filterContext.HttpContext.Request.UserHostAddress,
                    filterContext.HttpContext.Timestamp
                    );
            }
            catch (Exception ex)
            {
                ex.LogException(filterContext.HttpContext.Request);
            }
        }


    }
}