﻿using System;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using AwMvcStore.AwDatabase;
using AwMvcStore.Utils;

namespace AwMvcStore.Models
{
    public class AwProductAndDescription
    {
        public AwProduct Product { get; set; }
        public AwProductDescription ProductDescription { get; set; }
        public AwProductModel ProductModel { get; set; }
        public AwProductModelProductDescriptionCulture ProductModelProductDescriptionCulture { get; set; }
        private AwProductPhoto _photo;

        // Quick access / formatting for common properties
        [Display(Name = "Short Description")]
        public string ShortDescription
        {
            get { return ProductDescription == null ? "" : ProductDescription.Description.GetXWords(20, "..."); }
            set { if (ProductDescription != null) ProductDescription.Description = value; }
        }

        [Display(Name = "Description")]
        public string Description
        {
            get { return ProductDescription == null ? "" : ProductDescription.Description; }
            set { if (ProductDescription != null) ProductDescription.Description = value; }
        }

        [DataType(DataType.Currency), Display(Name = "Price")]
        public decimal Price
        {
            get { return Product == null ? 0 : Product.ListPrice; }
            set { if (Product != null) Product.ListPrice = value; }
        }

        [Display(Name = "Product Name")]
        public string Name
        {
            get { return Product == null ? "" : Product.Name; }
            set { if (Product != null) Product.Name = value; }
        }

        [Display(Name = "Product Model")]
        public string Model
        {
            get { return ProductModel == null ? "" : ProductModel.Name; }
            set { if (ProductModel != null) ProductModel.Name = value; }
        }

        [Display(Name = "Product Thumbnail")]
        public string PhotoThumbnail
        {
            get { return GetThumbnailPath(); }
        }

        [Display(Name = "Product Image")]
        public string PhotoLarge
        {
            get { return GetPhotoPath(); }
        }




        // Simple helpers to extract the produc photo from the DB
        private void RefreshProductPhoto()
        {
            try
            {
                RnLogger.Instance.LogDebug("Fetching photo information from DB for '{0}'", 1007, Name);

                var photo =
                    from pp in AwDbContext.Instance.Db.AwProductProductPhotos
                    join p in AwDbContext.Instance.Db.AwProductPhotos on pp.ProductPhotoID equals p.ProductPhotoID
                    where pp.ProductID == Product.ProductID
                    select p;

                _photo = photo.FirstOrDefault();
            }
            catch (Exception ex)
            {
                ex.LogException();
            }
        }

        private string GetThumbnailPath()
        {
            const string imgBase = "Images/Products/Thumbnails/";
            var imgDir = String.Format("{0}{1}", AppDomain.CurrentDomain.BaseDirectory, imgBase);

            try
            {
                if (_photo == null)
                    RefreshProductPhoto();

                if (_photo != null)
                {
                    var imgNameFull = String.Format("{0}{1}", imgDir, _photo.ThumbnailPhotoFileName);

                    if (File.Exists(imgNameFull))
                    {
                        // note: there would be logic here to make sure that the product image is replaced
                        //       if it was updated in the DB (using "ModifiedDate")
                        return String.Format("/{0}{1}", imgBase, _photo.ThumbnailPhotoFileName);
                    }

                    // Dump the file to disk
                    RnLogger.Instance.LogDebug("Refreshing thumbnail image for '{0}'", 1003, Name);
                    if (!Directory.Exists(imgDir)) Directory.CreateDirectory(imgDir);
                    if (RnUtils.WriteAllBinary(imgNameFull, _photo.ThumbNailPhoto))
                        return String.Format("/{0}{1}", imgBase, _photo.ThumbnailPhotoFileName);
                }
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            RnLogger.Instance.LogWarning("Unable to find Thumbnail Image for product '{0}'", 1009, Name);
            return "/Images/no_product_large.gif";
        }

        private string GetPhotoPath()
        {
            const string imgBase = "Images/Products/Large/";
            var imgDir = String.Format("{0}{1}", AppDomain.CurrentDomain.BaseDirectory, imgBase);

            try
            {
                if (_photo == null)
                    RefreshProductPhoto();

                if (_photo != null)
                {
                    var imgNameFull = String.Format("{0}{1}", imgDir, _photo.LargePhotoFileName);

                    if (File.Exists(imgNameFull))
                    {
                        // note: there would be logic here to make sure that the product image is replaced
                        //       if it was updated in the DB (using "ModifiedDate")
                        return String.Format("/{0}{1}", imgBase, _photo.LargePhotoFileName);
                    }

                    // Dump the file to disk
                    RnLogger.Instance.LogDebug("Refreshing product image for '{0}'", 1004, Name);
                    if (!Directory.Exists(imgDir)) Directory.CreateDirectory(imgDir);

                    if (RnUtils.WriteAllBinary(imgNameFull, _photo.LargePhoto))
                        return String.Format("/{0}{1}", imgBase, _photo.LargePhotoFileName);
                }
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            RnLogger.Instance.LogWarning("Unable to find Large Image for product '{0}'", 1008, Name);
            return "/Images/no_product_large.gif";
        }

    }
}