﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace AwMvcStore.Utils
{
    public static class RnControllerUtils
    {

        /// <summary>
        /// Returns the desired key from a FormCollection object or the defaultValue
        /// </summary>
        /// <param name="col">The collection to query</param>
        /// <param name="keyName">Desired key name</param>
        /// <param name="defaultVal">Default value shoud there be an error or the key was not found</param>
        /// <returns>Key value</returns>
        public static string GetKeyValue(this FormCollection col, string keyName, string defaultVal = "")
        {
            try
            {
                // Check to see if we can find the requested key
                for (var i = 0; i < col.Count; i++)
                    if (col.Keys[i] == keyName)
                        return col.GetValue(keyName).AttemptedValue;

                // If the key was not found, return the default
                return defaultVal;
            }
            catch (Exception ex)
            {
                ex.LogException();
                return defaultVal;
            }
        }

        /// <summary>
        /// Converts a FormCollection into Dictionary&lt;string, string&gt;
        /// </summary>
        /// <param name="col">The form to convert</param>
        /// <returns>The Dictionary object</returns>
        public static Dictionary<string, string> ToDictionary(this FormCollection col)
        {
            try
            {
                // Was originally this
                /*
                 var dic = new Dictionary<string, string>();
                    foreach (var key in col.AllKeys)
                        dic.Add(key, col.GetValue(key).AttemptedValue);
                 */

                // Much better
                return col.AllKeys.ToDictionary(key => key, key => col.GetValue(key).AttemptedValue);
            }
            catch (Exception ex)
            {
                ex.LogException();
                return new Dictionary<string, string>();
            }
        }

    }
}