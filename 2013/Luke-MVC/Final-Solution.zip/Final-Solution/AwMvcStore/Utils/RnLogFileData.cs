﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using AwMvcStore.Controllers;

namespace AwMvcStore.Utils
{
    static class RnLogFileData
    {
        public static List<RnLogFileEntry> GetLogLines(int limit, string severity)
        {
            try
            {
                var data = GetLogFileData();
                if (!String.IsNullOrEmpty(data))
                    return ExtractEntries(data, severity).OrderByDescending(ll => ll.LineNo).Take(limit).ToList();
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return new List<RnLogFileEntry>();
        }

        private static string GetLogFileData()
        {
            try
            {
                if (RnLogger.Instance.LoggerEnabled)
                {
                    using (var fs = new FileStream(RnLogger.Instance.LogFilePath, FileMode.Open, FileAccess.Read,
                                            FileShare.Delete | FileShare.ReadWrite))
                    {
                        using (var sr = new StreamReader(fs))
                        {
                            fs.Position = 0;
                            return sr.ReadToEnd();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return String.Empty;
        }

        private static IEnumerable<RnLogFileEntry> ExtractEntries(string data, string severity)
        {
            var lines = new List<RnLogFileEntry>();

            try
            {
                // ^\[(\d{4}-\d{1,2}-\d{1,2} \d{1,2}:\d{1,2}:\d{1,2})\] \[(.*?)\] (\w+) \((\d+)\):.*?(?=(\[\d{4}.*?\]|\Z))
                const string rxp =
                    @"^\[(\d{4}-\d{1,2}-\d{1,2} \d{1,2}:\d{1,2}:\d{1,2})\] \[(.*?)\] (\w+) \((\d+)\):(.*?)(?=(\[\d{4}.*?\]|\Z))";
                var matches = Regex.Matches(data, rxp,
                                            RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Singleline);
                var lineCounter = 0;
                if (severity.ToLower() == "all") severity = "";

                lines.AddRange(
                    from Match m in matches
                    let e = new RnLogFileEntry(m, lineCounter++)
                    where e.ParsedSuccessfully
                    where e.Severity.Contains(severity.ToLower())
                    select new RnLogFileEntry(m, lineCounter));
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return lines;
        }

    }
}