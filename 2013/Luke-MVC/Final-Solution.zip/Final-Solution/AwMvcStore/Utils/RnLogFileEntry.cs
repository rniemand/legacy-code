﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace AwMvcStore.Utils
{
    public class RnLogFileEntry
    {
        [Display(Name = "#")]
        public int LineNo { get; set; }

        [Display(Name = "Time Logged")]
        public string Date { get; set; }

        [Display(Name = "Method")]
        public string Method { get; set; }

        [Display(Name = "Severity")]
        public string Severity { get; set; }

        [Display(Name = "Event ID")]
        public int EventId { get; set; }

        [Display(Name = "Message")]
        public string Message { get; set; }

        public bool ParsedSuccessfully { get; private set; }

        public RnLogFileEntry(Match m, int lineNo)
        {
            try
            {
                LineNo = lineNo;
                Date = m.Groups[1].Value;
                Method = m.Groups[2].Value;
                Severity = m.Groups[3].Value.ToLower();
                EventId = m.Groups[4].Value.AsInt();
                Message = m.Groups[5].Value;
                ParsedSuccessfully = true;
            }
            catch (Exception ex)
            {
                ex.LogException();
                ParsedSuccessfully = false;
            }
        }

    }
}