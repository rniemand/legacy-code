﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Web;

/* *********************************************************************************************************
 *  RnLogger (Logging Helper)
 * *********************************************************************************************************
 * This is a simple logging class used to help me troubleshoot my code while I was developing it.
 * 
 * This was ported across from some of my older c# projects and adapted to work here. For simplicity and 
 * accessibility I am making use of a singleton here, but I would consider using a proper logging framework 
 * should I have the time to google around for a nice one.
 * 
 * Things to note here . . .
 * 
 *      1) Simple use of a singleton for ensuring only one logger.
 *      2) Use of method overrides (for different use cases).
 *      3) Use of System.IO and FileStream/StreamWriter
 *      4) Use of StackTrace to work out the calling method information.
 *      5) Use of extension methods for some data transformation.
 *      6) Use of “ConfigurationManager.AppSettings” to load custom configuration.
 *      7) Logic used for logging / file management.
 *      8) Using HttpRequestBase to pull out useful information about a request made to the logger
 *      9) Configuration of the logging level / modes from "Web.config"
 *  
 ********************************************************************************************************* */

namespace AwMvcStore.Utils
{
    public sealed class RnLogger
    {
        public string LogFilePath { get; internal set; }
        public int LogFileRollSizeMb { get; internal set; }
        public int LogsToKeep { get; internal set; }
        public Severity LoggingSeverity { get; internal set; }
        public bool LogPageActions { get; internal set; }
        public bool LoggerEnabled { get; private set; }

        private readonly long _rollSize;
        private FileStream _fs;
        private StreamWriter _sw;

        #region Constructor
        private static readonly RnLogger instance = new RnLogger();

        private RnLogger()
        {
            try
            {
                // Check to see if we can log
                if (!RnUtils.GetAppSettingBool("Rn.Logging.Enabled"))
                    return;

                // Get logging configuration from "Web.Config"
                LogFilePath = RnUtils.GetAppSetting("Rn.Logging.LogFilePath", @"c:\RnCore\AwMvcStore.log");
                LogFileRollSizeMb = RnUtils.GetAppSettingInt("Rn.Logging.MaxLogSizeMb", 5);
                LogsToKeep = RnUtils.GetAppSettingInt("Rn.Logging.KeepRolledLogs", 10);
                LoggingSeverity = RnUtils.GetAppSetting("Rn.Logging.LoggingLevel", "info").AsLoggingSeverity();
                LogPageActions = RnUtils.GetAppSettingBool("Rn.Logging.LogPageActions");

                // Set up internals and open our log file
                LoggerEnabled = false;
                _rollSize = (LogFileRollSizeMb*1048576);
                OpenLogFile();
            }
            catch
            {
                // just ignoring these for now, would use something like elmah (https://code.google.com/p/elmah/) down the line
            }
        }

        public static RnLogger Instance
        {
            get { return instance; }
        }
        #endregion

        #region Log File Write Methods
        private void OpenLogFile()
        {
            try
            {
                // Open the log file and position the cursor at the EOF
                if (!CheckLoggingDir()) return;
                _fs = new FileStream(LogFilePath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.Read);
                _fs.Position = _fs.Length;
                _sw = new StreamWriter(_fs);
                LoggerEnabled = true;
            }
            catch
            {
                // just ignoring these for now, would use something like elmah (https://code.google.com/p/elmah/) down the line
            }
        }

        private bool CheckLoggingDir()
        {
            try
            {
                var logFileDir = Path.GetDirectoryName(LogFilePath);
                if (logFileDir == null) return false;

                if (!Directory.Exists(logFileDir))
                    Directory.CreateDirectory(logFileDir);
                return Directory.Exists(logFileDir);
            }
            catch
            {
                // just ignoring these for now, would use something like elmah (https://code.google.com/p/elmah/) down the line
                return false;
            }
        }

        private void CloseLogFile()
        {
            if (_fs == null || _sw == null)
                return;

            try
            {
                _sw.Flush();
                _fs.Flush();
                _sw.Close();
                _fs.Close();
            }
            catch
            {
                // just ignoring these for now, would use something like elmah (https://code.google.com/p/elmah/) down the line
            }
        }

        /// <summary>
        /// Writes the current message to the active log file
        /// </summary>
        /// <param name="msg">The message to write to the log</param>
        /// <param name="sev">The severity of the message</param>
        /// <param name="eventId">The event ID for the message</param>
        /// <param name="framesBack">Amount of frames back that the message was from</param>
        private void WriteLine(string msg, Severity sev, int eventId = 0, int framesBack = 3)
        {
            if (!LoggerEnabled) return;

            try
            {
                var sb = new StringBuilder();

                if (_fs.Length >= _rollSize) RollLogFile();

                sb.Append(String.Format(
                    "[{0}] [{1}] {2}",
                    GetFullDate(),
                    GetMethodName(false, framesBack),
                    sev.ToString().ToUpper())
                    );

                if (eventId != 0)
                    sb.Append(String.Format(" ({0})", eventId));

                sb.Append(": " + msg);

                _sw.WriteLine(sb.ToString());
                _fs.Flush();
                _sw.Flush();
            }
            catch
            {
                // just ignoring these for now, would use something like elmah (https://code.google.com/p/elmah/) down the line
            }
        }

        private void RollLogFile()
        {
            try
            {
                CloseLogFile();

                for (var i = LogsToKeep; i >= 1; i--)
                {
                    var curName = String.Format("{0}.{1}", LogFilePath, i);
                    var newName = String.Format("{0}.{1}", LogFilePath, i + 1);

                    if (i == LogsToKeep && File.Exists(curName))
                    {
                        File.Delete(curName);
                        continue;
                    }

                    if (File.Exists(curName))
                        File.Move(curName, newName);
                }

                if (File.Exists(LogFilePath))
                    File.Move(LogFilePath, String.Format("{0}.1", LogFilePath));

                OpenLogFile();
            }
            catch
            {
                // just ignoring these for now, would use something like elmah (https://code.google.com/p/elmah/) down the line
            }
        } 
        #endregion


        // =====> Generic logging methods
        /// <summary>
        /// Writes an error message to the log
        /// </summary>
        /// <param name="message">The message to be sent to the log file</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        public void LogError(string message, int eventId = 0, params object[] replace)
        {
            if (CanLogEvent(Severity.Error))
                WriteLine(FormatMsg(message, replace), Severity.Error, eventId);
        }

        /// <summary>
        /// Writes a warning message to the log
        /// </summary>
        /// <param name="message">The message to be sent to the log file</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        public void LogWarning(string message, int eventId = 0, params object[] replace)
        {
            if (CanLogEvent(Severity.Warning))
                WriteLine(FormatMsg(message, replace), Severity.Warning, eventId);
        }

        /// <summary>
        /// Writes an informational message to the log
        /// </summary>
        /// <param name="message">The message to be sent to the log file</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        public void LogInfo(string message, int eventId = 0, params object[] replace)
        {
            if (CanLogEvent(Severity.Information))
                WriteLine(FormatMsg(message, replace), Severity.Information, eventId);
        }

        /// <summary>
        /// Writes a debug message to the log
        /// </summary>
        /// <param name="message">The message to be sent to the log file</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        public void LogDebug(string message, int eventId = 0, params object[] replace)
        {
            if (CanLogEvent(Severity.Debug))
                WriteLine(FormatMsg(message, replace), Severity.Debug, eventId);
        }

        /// <summary>
        /// Logs an exception to the event log
        /// </summary>
        /// <param name="message">The exception message</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        public void LogEx(string message, int eventId = 0)
        {
            // we always log an exception
            WriteLine(message, Severity.Error, eventId, 4);
        }


        // =====> Request based logging methods
        /// <summary>
        /// Writes an error message to the log
        /// </summary>
        /// <param name="message">The message to be sent to the log file</param>
        /// <param name="request">The HttpRequestBase object for context</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        public void LogError(string message, HttpRequestBase request, int eventId = 0, params object[] replace)
        {
            if (CanLogEvent(Severity.Error))
                WriteLine(FormatRequestMethod(message, request, replace), Severity.Error, eventId);
        }

        /// <summary>
        /// Writes a warning message to the log
        /// </summary>
        /// <param name="message">The message to be sent to the log file</param>
        /// <param name="request">The HttpRequestBase object for context</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        public void LogWarning(string message, HttpRequestBase request, int eventId = 0, params object[] replace)
        {
            if (CanLogEvent(Severity.Warning))
                WriteLine(FormatRequestMethod(message, request, replace), Severity.Warning, eventId);
        }


        /// <summary>
        /// Writes an informational message to the log
        /// </summary>
        /// <param name="message">The message to be sent to the log file</param>
        /// <param name="request">The HttpRequestBase object for context</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        public void LogInfo(string message, HttpRequestBase request, int eventId = 0, params object[] replace)
        {
            if (CanLogEvent(Severity.Information))
                WriteLine(FormatRequestMethod(message, request, replace), Severity.Information, eventId);
        }

        /// <summary>
        /// Writes a debug message to the log
        /// </summary>
        /// <param name="message">The message to be sent to the log file</param>
        /// <param name="request">The HttpRequestBase object for context</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        public void LogDebug(string message, HttpRequestBase request, int eventId = 0, params object[] replace)
        {
            if (CanLogEvent(Severity.Debug))
                WriteLine(FormatRequestMethod(message, request, replace), Severity.Debug, eventId);
        }

        /// <summary>
        /// Writes an exception to the log file
        /// </summary>
        /// <param name="message">The message to be written to the log</param>
        /// <param name="request">The HttpRequestBase object for context</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        public void LogEx(string message, HttpRequestBase request, int eventId = 0)
        {
            // Always log Exceptions
            WriteLine(FormatRequestMethod(message, request), Severity.Error, eventId, 4);
        }

        /// <summary>
        /// Used to log a page request
        /// </summary>
        /// <param name="message">The message to log</param>
        /// <param name="request">The HttpRequestBase object for context</param>
        /// <param name="eventId">The event ID (if any) for this message</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        public void LogActionCall(string message, HttpRequestBase request, int eventId = 0, params object[] replace)
        {
            if (LogPageActions)
                WriteLine(FormatRequestMethod(message, request, replace), Severity.Debug, eventId);
        }


        // Helper Methods
        /// <summary>
        /// Returns the current TimeStamp in a nce logging format
        /// </summary>
        /// <returns>he current TimeStamp in a loggable format</returns>
        public static string GetFullDate()
        {
            var sb = new StringBuilder();
            var dt = DateTime.Now;

            sb.Append(dt.Year.ToString(CultureInfo.InvariantCulture));
            sb.Append("-");
            sb.Append(dt.Month.ToString(CultureInfo.InvariantCulture).PadLeft(2, '0'));
            sb.Append("-");
            sb.Append(dt.Day.ToString(CultureInfo.InvariantCulture).PadLeft(2, '0'));
            sb.Append(" ");
            sb.Append(dt.Hour.ToString(CultureInfo.InvariantCulture).PadLeft(2, '0'));
            sb.Append(":");
            sb.Append(dt.Minute.ToString(CultureInfo.InvariantCulture).PadLeft(2, '0'));
            sb.Append(":");
            sb.Append(dt.Second.ToString(CultureInfo.InvariantCulture).PadLeft(2, '0'));

            return sb.ToString();
        }

        /// <summary>
        /// Returns the Method Name for the given amount of frames back
        /// </summary>
        /// <param name="shortName">True - just the name, False - fully qualified name</param>
        /// <param name="framesBack">The amount of fames to look back</param>
        /// <returns>Method name</returns>
        public static string GetMethodName(bool shortName = false, int framesBack = 2)
        {
            try
            {
                var methodInfo = new StackTrace().GetFrame(framesBack).GetMethod();

                if (shortName)
                    if (methodInfo.DeclaringType != null)
                        return String.Format("{0}.{1}", (methodInfo.DeclaringType).FullName, methodInfo.Name);

                if (methodInfo.DeclaringType != null)
                    return String.Format("{0}.{1}", (methodInfo.DeclaringType).Name, methodInfo.Name);

                return "Unknown.Method";
            }
            catch
            {
                // just ignoring these for now, would use something like elmah (https://code.google.com/p/elmah/) down the line
                return "Unknown.Method";
            }
        }

        /// <summary>
        /// Replaces / formats the current request based message
        /// </summary>
        /// <param name="msg">The message string to format</param>
        /// <param name="request">The HttpRequestBase object to pull information from</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        /// <returns>Formatted message</returns>
        private static string FormatRequestMethod(string msg, HttpRequestBase request, params object[] replace)
        {
            try
            {
                var fullMessage = new StringBuilder();
                fullMessage.Append(FormatMsg(msg, replace));
                fullMessage.Append(Environment.NewLine);
                fullMessage.Append("                      "); // Space it nicely for the date
                fullMessage.Append(String.Format("(Browser: {0})", request.Browser.Browser));
                fullMessage.Append(String.Format("(Method: {0})", request.HttpMethod));
                if (request.Url != null)
                {
                    fullMessage.Append(String.Format("(URL: {0})", request.Url.AbsoluteUri));
                }

                return fullMessage.ToString();
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return msg;
        }

        /// <summary>
        /// Replaces / formats the given message
        /// </summary>
        /// <param name="message">The message string to format</param>
        /// <param name="replace">Collection of values to replace in the message string</param>
        /// <returns>Formatted message string</returns>
        private static string FormatMsg(string message, params object[] replace)
        {
            try
            {
                if (replace.Length > 0)
                    return String.Format(message, replace);
                return message;
            }
            catch
            {
                // just ignoring these for now, would use something like elmah (https://code.google.com/p/elmah/) down the line
                return message;
            }
        }

        /// <summary>
        /// Used to determine if we can log the current message severity
        /// </summary>
        /// <param name="checkSeverity">Desired logging severity</param>
        /// <returns>True if can log, False otherwise</returns>
        private bool CanLogEvent(Severity checkSeverity)
        {
            return checkSeverity >= LoggingSeverity;
        }

    }

    public enum Severity
    {
        Debug = 1,
        Information = 2,
        Warning = 4,
        Error = 8
    }

    public static class RnLoggerHelper
    {
        /// <summary>
        /// Write the current exception to an event log
        /// </summary>
        /// <param name="ex">The exception to log</param>
        public static void LogException(this Exception ex)
        {
            try
            {
                RnLogger.Instance.LogEx(ex.Message, 100);
            }
            catch
            {
                // just ignoring these for now, would use something like elmah (https://code.google.com/p/elmah/) down the line
            }
        }

        /// <summary>
        /// Write the current exception to an event log
        /// </summary>
        /// <param name="ex">The exception to log</param>
        /// <param name="request">The HttpRequestBase object to add some ontext to the message</param>
        public static void LogException(this Exception ex, HttpRequestBase request)
        {
            try
            {
                RnLogger.Instance.LogEx(ex.Message, request, 100);
            }
            catch
            {
                // just ignoring these for now, would use something like elmah (https://code.google.com/p/elmah/) down the line
            }
        }

        /// <summary>
        /// Converts the given object into a logging Severity
        /// </summary>
        /// <param name="o">The object to try convert</param>
        /// <param name="defaultValue">A default Severity to use if not found, or an error occurs</param>
        /// <returns>Calculated logging Severity</returns>
        public static Severity AsLoggingSeverity(this object o, Severity defaultValue = Severity.Information)
        {
            try
            {
                // Try to match the logging severity
                switch (o.ToString().ToLower().Trim())
                {
                    case "debug":
                    case "full":
                    case "all":
                        return Severity.Debug;
                    case "info":
                    case "information":
                    case "informational":
                        return Severity.Information;
                    case "warning":
                    case "warn":
                        return Severity.Warning;
                    case "error":
                    case "wtf":
                        return Severity.Error;
                    default:
                        return defaultValue;
                }
            }
            catch (Exception ex)
            {
                // Whoops, return the default
                ex.LogException();
                return defaultValue;
            }
        }

    }

}