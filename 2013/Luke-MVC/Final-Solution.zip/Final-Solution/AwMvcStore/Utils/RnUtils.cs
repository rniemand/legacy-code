﻿using System;
using System.Configuration;
using System.Data.Linq;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace AwMvcStore.Utils
{
    public static class RnUtils
    {
        /// <summary>
        /// Convert the given object into an int
        /// </summary>
        /// <param name="o">Object to convert</param>
        /// <param name="defaultVal">Default value if conversion fails</param>
        /// <returns>Converted object as int</returns>
        public static int AsInt(this object o, int defaultVal = 0)
        {
            try
            {
                return int.Parse(o.ToString());
            }
            catch (Exception ex)
            {
                ex.LogException();
                return defaultVal;
            }
        }

        /// <summary>
        /// Convert the given object into a bool
        /// </summary>
        /// <param name="o">Object to convert</param>
        /// <param name="defaultValue">Default value if conversion fails</param>
        /// <returns>Converted object as bool</returns>
        public static bool AsBool(this object o, bool defaultValue)
        {
            try
            {
                var clean = o.ToString().Trim().ToLower();
                switch (clean)
                {
                    case "0":
                    case "false":
                        return false;
                    case "1":
                    case "true":
                        return true;
                    default:
                        return defaultValue;
                }
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return defaultValue;
        }

        /// <summary>
        /// Returns the first x words in a string
        /// </summary>
        /// <param name="s">The string to use</param>
        /// <param name="numberWords">Amount of words back</param>
        /// <param name="moreIndicator">Indicator to append if words were truncated</param>
        /// <returns>First x words of the given string</returns>
        public static string GetXWords(this string s, int numberWords, string moreIndicator = "")
        {
            try
            {
                var words = s.Split(' ');
                if (words.Length <= numberWords) return s;
                return String.Join(" ", words.Take(numberWords)) + moreIndicator;
            }
            catch (Exception ex)
            {
                ex.LogException();
                return s;
            }
        }

        /// <summary>
        /// Writes the given binary chunk to disk
        /// </summary>
        /// <param name="filePath">File path to write to</param>
        /// <param name="data">Binary data to write</param>
        /// <returns>True if success, False if an error/fail</returns>
        public static bool WriteAllBinary(string filePath, Binary data)
        {
            try
            {
                using (var b = new BinaryWriter(File.Open(filePath, FileMode.Create)))
                    foreach (var i in data.ToArray())
                        b.Write(i);

                return true;
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return false;
        }

        /// <summary>
        /// Returns a bool value from the current application settings
        /// </summary>
        /// <param name="keyName">The application settings key</param>
        /// <param name="defaultValue">Default value to return should the conversion/lookup fail</param>
        /// <returns>The requested key as a bool value</returns>
        public static bool GetAppSettingBool(string keyName, bool defaultValue = false)
        {
            try
            {
                // Check for the requested key
                var val = ConfigurationManager.AppSettings.GetValues(keyName);
                return val != null ? val[0].AsBool(defaultValue) : defaultValue;
            }
            catch (Exception ex)
            {
                ex.LogException();
                return defaultValue;
            }
        }

        /// <summary>
        /// Returns the value from the current application settings
        /// </summary>
        /// <param name="keyName">The application settings key</param>
        /// <param name="defaultValue">Default value to return should the conversion/lookup fail</param>
        /// <returns>The requested key value</returns>
        public static string GetAppSetting(string keyName, string defaultValue = "")
        {
            try
            {
                // Check for the requested key
                var val = ConfigurationManager.AppSettings.GetValues(keyName);
                return val != null ? val[0] : defaultValue;
            }
            catch (Exception ex)
            {
                ex.LogException();
                return defaultValue;
            }
        }

        /// <summary>
        /// Returns a int value from the current application settings
        /// </summary>
        /// <param name="keyName">The application settings key</param>
        /// <param name="defaultValue">Default value to return should the conversion/lookup fail</param>
        /// <returns>The requested key as a int value</returns>
        public static int GetAppSettingInt(string keyName, int defaultValue = 0)
        {
            try
            {
                // Check for the requested key
                var val = ConfigurationManager.AppSettings.GetValues(keyName);
                return val != null ? val[0].AsInt(defaultValue) : defaultValue;
            }
            catch (Exception ex)
            {
                ex.LogException();
                return defaultValue;
            }
        }

        /// <summary>
        /// Generate an image link
        /// </summary>
        /// <param name="helper">The HtmlHelper objects context</param>
        /// <param name="imageUrl">The URL to the image (relative paths work too)</param>
        /// <param name="altText">The alt tag value for the image</param>
        /// <param name="actionName">The name of the ACTION</param>
        /// <param name="controller">The name of the CONTROLLER</param>
        /// <param name="routeValues">Object for routing values</param>
        /// <param name="_imageClass">A CSS class to assign to the imae</param>
        /// <param name="htmlAttributes">Additional attributes for the link</param>
        /// <param name="useAltAsLinkText">True use the alt tag value as the a tags text</param>
        /// <returns>The generated link as an MvcHtmlString object</returns>
        /// <remarks>http://stackoverflow.com/questions/8173956/how-do-i-make-an-image-a-part-of-my-html-actionlink</remarks>
        public static MvcHtmlString ActionImageLink(this HtmlHelper helper, string imageUrl, string altText, string actionName, string controller, object routeValues, string _imageClass = "", object htmlAttributes = null, bool useAltAsLinkText = false)
        {
            // http://stackoverflow.com/questions/8173956/how-do-i-make-an-image-a-part-of-my-html-actionlink

            try
            {
                var img = new TagBuilder("img");
                img.MergeAttribute("src", imageUrl);
                img.MergeAttribute("alt", altText);
                if (!String.IsNullOrEmpty(_imageClass))
                    img.MergeAttribute("class", _imageClass);
                var link = helper.ActionLink("[r]", actionName, controller, routeValues, htmlAttributes);
                var app = useAltAsLinkText ? " " + altText : "";
                return new MvcHtmlString(link.ToHtmlString().Replace("[r]", img.ToString(TagRenderMode.SelfClosing) + app));
            }
            catch (Exception ex)
            {
                ex.LogException();
                return new MvcHtmlString("");
            }
        }

        /// <summary>
        /// Returns a random 404 image
        /// </summary>
        /// <param name="imageDir">Directory to scan for images</param>
        /// <returns>Path to a random image in the given directory</returns>
        public static string Get404Image(string imageDir)
        {
            try
            {
                var imgDir = String.Format("{0}{1}", AppDomain.CurrentDomain.BaseDirectory, imageDir);
                var dir = new DirectoryInfo(imgDir);
                var files = dir.GetFiles();

                if (files.Length > 0)
                {
                    var r = new Random(DateTime.Now.Millisecond + DateTime.Now.Second * 2 / 4);
                    var fileNo = r.Next(0, files.Length - 1);
                    return String.Format("/{0}{1}", imageDir, files[fileNo].Name);
                }
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return "/Images/404/tumblr_m266txp3c71r9g4gho1_500.jpg";
        }

    }
}