﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AwMvcStore.AwDatabase;
using AwMvcStore.Controllers;

namespace AwMvcStore.Utils
{
    static class StoreSearchHelper
    {
        /// <summary>
        /// Generates the "Base Query" for all AJAX store searches
        /// </summary>
        /// <returns>Base Query</returns>
        public static IQueryable<AjaxSearchResult> GenerateBaseQuery()
        {
            try
            {
                RnLogger.Instance.LogDebug("Generating base AJAX search query", 1019);
                var products =
                    from p in AwDbContext.Instance.Db.AwProducts
                    join pm in AwDbContext.Instance.Db.AwProductModels on p.ProductModelID equals pm.ProductModelID
                    join pmpc in AwDbContext.Instance.Db.AwProductModelProductDescriptionCultures on pm.ProductModelID
                        equals pmpc.ProductModelID
                    join pd in AwDbContext.Instance.Db.AwProductDescriptions on pmpc.ProductDescriptionID equals
                        pd.ProductDescriptionID
                    where pmpc.CultureID.Contains("en")
                    select new AjaxSearchResult
                    {
                        ProductName = p.Name,
                        ProductId = p.ProductID,
                        ProductDescription = pd.Description,
                        ProductDescriptionLocale = pmpc.CultureID,
                        ProductPrice = p.ListPrice,
                        ProductModel = pm.Name,
                        ProductDescriptionShort = pd.Description.GetXWords(20, "...")
                    };

                return products;
            }
            catch (Exception ex)
            {
                ex.LogException();
                return null;
            }
        }

        /// <summary>
        /// Applies the given search term to the "Base Query"
        /// </summary>
        /// <param name="items">The "Base Query"</param>
        /// <param name="term">Term to filter on</param>
        /// <returns>Modified "Base Query"</returns>
        public static IQueryable<AjaxSearchResult> ApplySearchTerm(this IQueryable<AjaxSearchResult> items,
                                                                   string term = "")
        {
            try
            {
                if (!String.IsNullOrEmpty(term))
                {
                    RnLogger.Instance.LogDebug("Applying the filter '{0}' on AJAX search query", 1020, term);
                    return items.Where(
                        p =>
                        p.ProductName.Contains(term) ||
                        p.ProductDescription.Contains(term) ||
                        p.ProductModel.Contains(term)
                        );
                }
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return items;
        }

        /// <summary>
        /// Applies specific ordering to the "Base Query"
        /// </summary>
        /// <param name="list">The "Base Query"</param>
        /// <param name="orderBy">Property and Direction to order on</param>
        /// <returns>Modified "Base Query"</returns>
        public static IQueryable<AjaxSearchResult> ApplyOrdering(this IQueryable<AjaxSearchResult> list,
                                                                 string orderBy = "ProductName")
        {
            try
            {
                RnLogger.Instance.LogDebug("Applying order '{0}' to AJAX search query", 1021, orderBy);

                switch (orderBy.ToLower().Trim())
                {
                    case "price":
                        return list.OrderBy(p => p.ProductPrice);
                    case "price desc":
                        return list.OrderByDescending(p => p.ProductPrice);
                    case "model":
                        return list.OrderBy(p => p.ProductModel);
                    case "model desc":
                        return list.OrderByDescending(p => p.ProductModel);
                    case "desc":
                        return list.OrderBy(p => p.ProductDescription);
                    case "desc desc":
                        return list.OrderByDescending(p => p.ProductDescription);
                    case "name desc":
                        return list.OrderByDescending(p => p.ProductName);
                    default:
                        return list.OrderBy(p => p.ProductName);
                }
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return list;
        }

        /// <summary>
        /// Applies a limit on the number of results the "Base Query" returns
        /// </summary>
        /// <param name="list">The "Base Query"</param>
        /// <param name="limit">Max number of results</param>
        /// <returns>Modified "Base Query"</returns>
        public static IQueryable<AjaxSearchResult> ApplyLimit(this IQueryable<AjaxSearchResult> list, int limit = 0)
        {
            try
            {
                if (limit > 0)
                {
                    RnLogger.Instance.LogDebug("Applying result limit '{0}' to AJAX query", 1022, limit);
                    return list.Take(limit);
                }
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return list;
        }

        /// <summary>
        /// Applies a limit on the number of results the "Base Query" returns
        /// </summary>
        /// <param name="list">The "Base Query"</param>
        /// <param name="limit">Max number of results</param>
        /// <returns>Modified "Base Query"</returns>
        /// <remarks>This is an overloaded method</remarks>
        public static IQueryable<AjaxSearchResult> ApplyLimit(this IQueryable<AjaxSearchResult> list, string limit = "0")
        {
            try
            {
                return ApplyLimit(list, limit.AsInt());
            }
            catch (Exception ex)
            {
                ex.LogException();
            }

            return list;
        }

    }
}