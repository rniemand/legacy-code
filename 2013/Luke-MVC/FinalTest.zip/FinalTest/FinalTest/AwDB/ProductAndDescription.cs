﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FinalTest.AwDB
{
    public class ProductAndDescription
    {
        public Product Product { get; set; }
        public ProductDescription ProductDescription { get; set; }
        public ProductModel ProductModel { get; set; }
        public ProductModelProductDescriptionCulture ProductModelProductDescriptionCulture { get; set; }
    }
}