﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FinalTest.AwDB;
using PagedList;

namespace FinalTest.Controllers
{
    public class TestController : Controller
    {
        private AwDbLinqDataContext db = new AwDbLinqDataContext();

        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParam = String.IsNullOrEmpty(sortOrder) ? "Name desc" : "";
            ViewBag.IdSortParam = sortOrder == "ID" ? "ID desc" : "ID";
            ViewBag.PriceSortParam = sortOrder == "Price" ? "Price desc" : "Price";
            ViewBag.ModelSortParam = sortOrder == "Model" ? "Model desc" : "Model";
            ViewBag.DescSortParam = sortOrder == "Description" ? "Description desc" : "Description";

            if (Request.HttpMethod == "GET")
                searchString = currentFilter;
            else
                page = 1;

            ViewBag.CurrentFilter = searchString;

            var results =
                from p in db.Products
                join pm in db.ProductModels on p.ProductModelID equals pm.ProductModelID
                join pmpc in db.ProductModelProductDescriptionCultures on pm.ProductModelID equals pmpc.ProductModelID
                join desc in db.ProductDescriptions on pmpc.ProductDescriptionID equals desc.ProductDescriptionID
                where pmpc.CultureID.Contains("en")
                select new ProductAndDescription
                    {
                        Product = p,
                        ProductDescription = desc,
                        ProductModel = pm,
                        ProductModelProductDescriptionCulture = pmpc
                    };

            switch (sortOrder)
            {
                case "Description":
                    results = results.OrderBy(p => p.ProductDescription.Description);
                    break;
                case "Description desc":
                    results = results.OrderByDescending(p => p.ProductDescription.Description);
                    break;
                case "Model":
                    results = results.OrderBy(p => p.ProductModel.Name);
                    break;
                case "Model desc":
                    results = results.OrderByDescending(p => p.ProductModel.Name);
                    break;
                case "Price":
                    results = results.OrderBy(p => p.Product.ListPrice);
                    break;
                case "Price desc":
                    results = results.OrderByDescending(p => p.Product.ListPrice);
                    break;
                case "ID":
                    results = results.OrderBy(p => p.Product.ProductID);
                    break;
                case "ID desc":
                    results = results.OrderByDescending(p => p.Product.ProductID);
                    break;
                case "Name desc":
                    results = results.OrderByDescending(p => p.Product.Name);
                    break;
                default:
                    results = results.OrderBy(p => p.Product.Name);
                    break;
            }

            return View(results.ToPagedList((page ?? 1), 10));
        }

        public ActionResult Edit(int id)
        {
            var product =
                (from p in db.Products
                join pm in db.ProductModels on p.ProductModelID equals pm.ProductModelID
                join pmpc in db.ProductModelProductDescriptionCultures on pm.ProductModelID equals pmpc.ProductModelID
                join desc in db.ProductDescriptions on pmpc.ProductDescriptionID equals desc.ProductDescriptionID
                where p.ProductID.Equals(id)
                select new ProductAndDescription
                {
                    Product = p,
                    ProductDescription = desc,
                    ProductModel = pm,
                    ProductModelProductDescriptionCulture = pmpc
                }).FirstOrDefault();

            if (product == null)
                return HttpNotFound();

            return View(product);
        }

        [HttpPost]
        public ActionResult Edit(ProductAndDescription o)
        {
            // http://weblogs.asp.net/scottgu/archive/2007/07/11/linq-to-sql-part-4-updating-our-database.aspx
            // http://weblogs.asp.net/scottgu/archive/2007/07/11/linq-to-sql-part-4-updating-our-database.aspx

            if (ModelState.IsValid)
            {
                var desc = db.ProductDescriptions.Single(p => p.ProductDescriptionID == o.ProductDescription.ProductDescriptionID);
                var prod = db.Products.Single(p => p.ProductID == o.Product.ProductID);

                /*
                var desc =
                    (from d in db.ProductDescriptions
                     where d.ProductDescriptionID.Equals(o.ProductDescription.ProductDescriptionID)
                     select d).FirstOrDefault();
                */

                if (desc != null)
                    desc.Description = o.ProductDescription.Description;
                if (prod != null)
                {
                    prod.Name = o.Product.Name;
                    prod.ListPrice = o.Product.ListPrice;
                }
                    

                db.SubmitChanges();
                return RedirectToAction("Index");
            }

            return View(o);
        }


    }
}
