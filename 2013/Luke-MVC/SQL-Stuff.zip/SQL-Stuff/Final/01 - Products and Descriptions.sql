SELECT 
    p.[ProductID],
    p.[Name],
    pm.[Name] AS [ProductModel],
    pmx.[CultureID],
    pd.[Description],
	pm.[ProductModelID],
	p.[ProductModelID]
FROM [Production].[Product] p 
    INNER JOIN [Production].[ProductModel] pm ON p.[ProductModelID] = pm.[ProductModelID] 
    INNER JOIN [Production].[ProductModelProductDescriptionCulture] pmx ON pm.[ProductModelID] = pmx.[ProductModelID] 
    INNER JOIN [Production].[ProductDescription] pd ON pmx.[ProductDescriptionID] = pd.[ProductDescriptionID]
WHERE
	pmx.CultureID = 'en'
	and p.[name] like '%moot%'
ORDER BY
	p.[Name]





/*
SELECT * FROM [Production].[Product] a WHERE a.ProductModelID = 2
SELECT * FROM [Production].[ProductModel] a WHERE a.ProductModelID = 2

SELECT a.ProductModelID, COUNT(1) as 'Count'
FROM [Production].[Product] a
WHERE a.ProductModelID IS NOT NULL
GROUP BY a.ProductModelID
ORDER BY COUNT(1) DESC

*/