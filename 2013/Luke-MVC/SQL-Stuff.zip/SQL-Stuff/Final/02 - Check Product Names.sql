SELECT 
    p.[ProductID],
    p.[Name],
    pm.[Name] AS [ProductModel],
    pmx.[CultureID],
    pd.[Description],
	pm.[ProductModelID],
	p.[ProductModelID]
FROM [Production].[Product] p 
    INNER JOIN [Production].[ProductModel] pm ON p.[ProductModelID] = pm.[ProductModelID] 
    INNER JOIN [Production].[ProductModelProductDescriptionCulture] pmx ON pm.[ProductModelID] = pmx.[ProductModelID] 
    INNER JOIN [Production].[ProductDescription] pd ON pmx.[ProductDescriptionID] = pd.[ProductDescriptionID]
WHERE
	pmx.CultureID = 'en'
	AND p.Name = 'Chain'
ORDER BY
	p.[Name]
