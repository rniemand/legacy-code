SELECT
	a.ProductID,
	a.Name,
	a.ListPrice,
	c.CultureID,
	d.[Description],
	d.ProductDescriptionID
FROM Production.Product a
	inner join Production.ProductModel b on a.ProductModelID = b.ProductModelID
	inner join Production.ProductModelProductDescriptionCulture c on b.ProductModelID = c.ProductModelID
	inner join Production.ProductDescription d on c.ProductDescriptionID = d.ProductDescriptionID
where c.CultureID = 'en'
	and a.ProductID = 994