
/*
SELECT TOP 10
	*
FROM [Production].[Product] a
	LEFT JOIN [Production].[ProductModel] b ON a.ProductModelID = b.ProductModelID
	--LEFT JOIN [Production].[ProductModelProductDescriptionCulture] c ON b.ProductModelID = c.ProductModelID
	--LEFT JOIN [Production].[ProductDescription] d ON c.ProductDescriptionID = d.ProductDescriptionID
ORDER BY a.ProductID


SELECT TOP 10
	a.ProductID,
	a.Name,
	a.ProductNumber,
	a.ProductModelID,
	b.*
FROM [Production].[Product] a
LEFT JOIN [Production].[ProductModel] b ON a.ProductModelID = b.ProductModelID

ORDER BY a.ProductID ASC
*/


SELECT TOP 1000 [ProductID]
      ,[Name]
      ,[ProductModel]
      ,[CultureID]
      ,[Description]
  FROM [Production].[vProductAndDescription]
  where CultureID = 'en'