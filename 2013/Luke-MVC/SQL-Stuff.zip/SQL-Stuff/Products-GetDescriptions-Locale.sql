SELECT TOP 100
	*
FROM [Production].[Product] a
	LEFT JOIN [Production].[ProductModel] b ON a.ProductModelID = b.ProductModelID
	LEFT JOIN [Production].[ProductModelProductDescriptionCulture] c ON b.ProductModelID = c.ProductModelID
	LEFT JOIN [Production].[ProductDescription] d ON c.ProductDescriptionID = d.ProductDescriptionID
ORDER BY a.ProductID