-- --------------------------------------------------------
-- Host:                         192.168.0.5
-- Server version:               5.6.10 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL version:             7.0.0.4053
-- Date/time:                    2013-03-07 21:42:44
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

-- Dumping database structure for squid
CREATE DATABASE IF NOT EXISTS `squid` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `squid`;


-- Dumping structure for table squid.tb_access_raw
CREATE TABLE IF NOT EXISTS `tb_access_raw` (
  `accessId` bigint(20) NOT NULL AUTO_INCREMENT,
  `timestamp` datetime DEFAULT NULL,
  `elapsed` int(11) DEFAULT NULL,
  `client` varchar(64) DEFAULT NULL,
  `action` varchar(64) DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `method` varchar(16) DEFAULT NULL,
  `baseUrl` varchar(128) DEFAULT NULL,
  `fullUrl` varchar(512) DEFAULT NULL,
  `ident` varchar(32) DEFAULT NULL,
  `hierarchy` varchar(32) DEFAULT NULL,
  `from` varchar(64) DEFAULT NULL,
  `content` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`accessId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
/*!40014 SET FOREIGN_KEY_CHECKS=1 */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
